/*@ axiomatic power {
  @ logic integer power(integer n,integer m);
  @ axiom pow1: \forall integer n; n >= 1 ==>  power(n,0) == 1;
  @ axiom mathfact_rec: \forall integer n,p; n > 1 && p >=0 
  ==> power(n,p+1) == power(n,p)*n;
  @ } */

/* lemma   prop : \forall integer n,m,p; n >= 0  && p >=0 && m >= 0 ==> power(3,n)*power(3,m)*power(3,p)== power(3,n+m+p); */ 
/*@ requires  x0 == power(3,n) && y0 == power(3,p) &&  z0==power(3,m) && n == p;
 */
void  ex81(int x0,int y0,int z0,int n,int p,int m) {
  int x = x0,y=y0,z=z0,t;
  //@  assert  x == power(3,n) && y == power(3,p) &&  z ==power(3,m);
  t = 8*x*y*z;
  // @  assert  t == power(y+z,3) &&  y == x;
  //@  assert  t == 8*power(3,n+m+p) &&  y == x;      
}
