  //@ admit p == q;
*p = 1;
//@ assert *p + *q == 2;

