gg#include <limits.h>
/*@ requires a >= 0 && b>= 0 && a+b <= INT_MAX; // ajput de a+b <= INT_MAX pour RTE
  @ assigns \nothing;
  @ ensures \result == \old(a)+\old(b)-2;

  @*/
int annotation(int a,int b)
{
  int x,y,z;
  x = a;
/*@  assert l1: x == a; */
  y = b;
/*@  assert l2: x == a && y == b; */
   z = a+b-2;
/*@  assert l3: x == a && y == b && z==a+b-2; */        
  return(z);  // \result = z
}
