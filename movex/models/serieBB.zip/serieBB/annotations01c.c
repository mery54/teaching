/*@ requires x == 12;
  assigns \nothing;
  ensures \result == 0;
 */
int ex(int x) {

   int y=24;
   //@ assert x==12 &&   y == 24;   
   x = x+1; 
   //@ assert   y == 2*(x-1);
   return(0);
   // \result = 0
  }

