//@ assert l1: P(x);
  x = e(x);
//@ assert l2: Q(x);
