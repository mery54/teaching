/*@ requires x >=  0 && x <= 10;
  @ assigns \nothing;
  @ ensures  x % 2 == 0 ==> 2*\result == x;
  @ ensures  x % 2 != 0 ==> 2*\result == x-1;
  @*/
int annotation(int x)
{
  int y;
   /*@ assert  x % 2 == 0 ==> 2* (x/2) == x; */
  /*@ assert   x % 2 != 0 ==> 2*(x/2) == x-1; */
  y  = x / 2;
  /*@ assert  x % 2 == 0 ==> 2*y == x; */
  /*@ assert   x % 2 != 0 ==> 2*y == x-1; */
  return(y);
  }
