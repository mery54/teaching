#include <limits.h>
#include <mathinv1.h>
/*@ requires x >=0;
    assigns \nothing;
    ensures \result ==  mathpower(2,x)-1;
*/
int inv1(int x)
{ int u=0;
  int k=0;
  /*@ loop invariant 0<= k && k <= x;
    @  loop invariant u == mathpower(2,k)-1;
     @ loop assigns u,k;
     @loop variant x-k;
  */ 
  while (k  < x)
    { u=2*u+1;
      k=k+1;
    };
  return(u);
    }

