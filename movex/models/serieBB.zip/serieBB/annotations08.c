/*@  assigns \nothing;
  @ ensures \result == x + 3;

  @*/
int  ex(int x) {
  int y;
  y = x;
  //@ assert l1:  y == x;
  y = y+1;
  //@ assert l2: y == x + 1;
  y = y + 2;
 //@ assert l3: y == x + 3;
  return(y);
}

