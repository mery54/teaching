void ex(void) {
  int x=12,y=24;
  //@ assert l1: 2*x == y;
   x = x+1;
  //@ assert l2:  y == 2*(x-1);
 }

