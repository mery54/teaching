/*@  assigns \nothing;
  @ ensures \result == x + 1;

  @*/
int  ex(int x) {
  int y;
  y = x;
  //@ assert l1:  y == x;
  y = y+1;
  //@ assert l2: y == x + 1;
   return(y);
}

