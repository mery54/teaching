#include <limits.h>

/*@
   requires  \valid(a) && \valid(b) ;
   assigns *a;
   assigns *b;
   ensures A: *a == \old(*b);
    ensures B: *b == \old(*a);
  @*/
void swap(int* a, int* b) {
  int tmp = *a;
  *a = *b;
  *b = tmp;
}


/*@
predicate 
Unchanged{K,L}(int* a, integer first, integer last) =
\forall integer i; first <= i < last ==> \at(a[i],K) == \at(a[i],L);
predicate
Unchanged{K,L}(int* a, integer n) = Unchanged{K,L}(a, 0, n);
*/



/*@
predicate
Reverse{A,B}(int* a, integer n, int* b, integer l, integer r) =
\forall integer k; l <= k < r ==> \at(a[k], A) == \at(b[n-1-k], B);
predicate
Reverse{A,B}(int* a, integer n, int* b) =
Reverse{A,B}(a, n, b, 0, n);
predicate
Reverse{A,B}(int* a, integer n) = Reverse{A,B}(a, n, a);
*/




/*@ 
  requires n >0;
  requires valid: \valid(a + (0..n-1));
  assigns a[0..(n-1)];
  ensures reverse: Reverse{Here,Old}(a, n);
*/
void reverse(int* a, int n)
{
  const int half = n / 2;
/*@
loop invariant bound: 0 <= i <= half;
loop invariant left: Reverse{Here,Pre}(a, n, a, 0, i);
loop invariant middle: Unchanged{Here,Pre}(a, i, n-i);
loop invariant right: Reverse{Here,Pre}(a, n, a, n-i, n);
loop assigns i, a[0..n-1];
loop variant half - i;
*/
for (int i = 0; i < half; ++i) {
swap(&a[i], &a[n - 1 - i]);
 };
}



