/*@ requires  x0 == 10 && y0 == z0+x0  &&  z0==2*x0;
 */
void  ex81(int x0,int y0,int z0) {
  int x = x0,y=y0,z=z0;
  //@  assert x == 10 && y == z+x&&  z==2*x;
  y = z+x;
  //@  assert x== 10 &&  y == x+2*10;
}


