
void ex(void) {

   int x=2,y=4,z,a=1;

  //@ assert x <= y;
  // => 
    //@ assert x*x == a*y;
  x = x*x;
  //@ assert x == a*y && x* 2*x >= 8;
   y = 2*x;
  z = x + y;
  //@ assert z == x+y && x* y >= 8;
}

