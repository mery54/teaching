#include <limits.h>

/*@   requires (x0 == 64) && ((2 * x0) == z0) &&  ((x0 * z0) == y0);
       assigns \nothing;
   ensures \result == 0;
 */
int annotation11(int x0,int y0,int z0)
{ int x=x0,y=y0,z=z0;

  //@ assert l1: x == 64 && y == x*z && z == 2*x;
  y = x*z;
  //@ assert l2: y*z == 2*x*x*z;
  return (0);
}
  
