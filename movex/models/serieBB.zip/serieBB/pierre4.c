/*@
predicate
EqualRanges{A,B}(int* a, integer m, integer n, int* b) =
\forall integer i; m <= i < n ==> \at(a[i], A) == \at(b[i], B);
predicate
EqualRanges{A,B}(int* a, integer n,int* b) =
EqualRanges{A,B}(a, 0, n, b);
*/

/*@
predicate
Unchanged{K,L}(int* a, integer first, integer last) =
\forall integer i; first <= i < last ==> \at(a[i],K) == \at(a[i],L);
predicate
Unchanged{K,L}(int* a, integer n) = Unchanged{K,L}(a, 0, n);
*/

/*@
requires n >0;
requires valid: \valid_read(a + (0..n-1));
requires valid: \valid(b + (0..n-1));
requires sep: \separated(a + (0..n-1), b);
assigns b[0..n-1];
ensures equal: EqualRanges{Old,Here}(a, n, b);
*/
void copy(const int* a, const int n, int* b)
{
/*@
loop invariant bound: 0 <= i <= n;
loop invariant equal: EqualRanges{Pre,Here}(a, i, b);
loop invariant equal: Unchanged{Pre,Here}(a, i, n);
loop assigns i, b[0..n-1];
loop variant n-i;
*/
for (int i = 0; i < n; ++i) {
b[i] = a[i];
}
}



