
void main()
{
  int *p;
  int *q;
  //@ admit p == q;
*p = 1;
//@ assert *p + *q == 2;
}
