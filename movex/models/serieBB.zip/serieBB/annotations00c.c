int annotations00(int x)
{
  int y;
   /*@ assert  x % 2 == 0 ==> 2* (x/2) == x; */
  /*@ assert   x % 2 != 0 ==> 2*(x/2) == x-1; */
  y  = x / 2;
  /*@ assert  x % 2 == 0 ==> 2*y == x; */
  /*@ assert   x % 2 != 0 ==> 2*y == x-1; */
  return(y);
  }
