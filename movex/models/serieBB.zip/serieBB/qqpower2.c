   #include <limits.h>
/*@ axiomatic auxmath {
  @ axiom  rule1: \forall int n; n >0 ==> n*n == (n-1)*(n-1)+2*n-1; 
  @ } */


/*@  requires  0 <= x; 
  requires  x  <= INT_MAX; 
  requires  x*x  <= INT_MAX; 
     ensures \result == x*x;
*/
int power2(int x)
{int  r,k,cv,cw,or,ok,ocv,ocw;
  r=0;k=0;cv=0;cw=0;or=0;ok=k;ocv=cv;ocw=cw;
      /*@ loop invariant cv == k*k;
         @ loop invariant 0 <= k && k  <= x;
         @ loop invariant cw  == 2*k;        
         @ loop invariant  4*cv  == cw*cw;
         @ loop assigns k,cv,cw,or,ok,ocv,ocw; 
         @ loop variant x-k;
*/
  while (k<x)
	{
	  ok=k;ocv=cv;ocw=cw;
	  k=ok+1;
	  cv=ocv+ocw+1;
	  cw=ocw+2;
	  
	}
  r=cv;
  return(r);
}



/*@  requires  0 <= x; 
  requires  x  <= INT_MAX; 
  requires  x*x  <= INT_MAX; 
     ensures \result == x*x;
*/
int npower2(int x)
{int  r,k,cv,cw;
  r=0;k=0;cv=0;cw=0;
      /*@ loop invariant cv == k*k;
         @ loop invariant 0 <= k && k  <= x;
         @ loop invariant cw  == 2*k;        
         @ loop invariant  4*cv  == cw*cw;
         @ loop assigns k,cv,cw;
         @ loop variant x-k;
*/
  while (k<x)
	{

	  k=k+1;
	  cv=cv+cw+1;
	  cw=cw+2;
	  
	}
  r=cv;
  return(r);
}



/*@  requires  0 <= x;
  requires  x  <= INT_MAX; 
  requires  x*x  <= INT_MAX; 
     decreases x;

     ensures \result == x*x;
*/
int p(int x)
{
  int r;
  if (x==0)
	{
	  r=0;
	  
	}
  else
	{
	  r= p(x-1)+2*x-1;
	  
	}    
  return(r);
}


/*@  requires  0 <= n;
requires  n*n  <= INT_MAX;
     ensures \result == 1;
*/

int check(int n){
  int r1,r2,r;
  r1 = power2(n);
  r2 =  npower2(n); 

  
  if (r1 != r2)
    { r = 0; // pas possible
    }
  else
    { r = 1;
    };
  return r;
 }




