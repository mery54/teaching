#include <stdio.h>
#include <stdlib.h>
#include "division.h"

struct s  division(int a, int b) 
{  int rr = a;
   int qq = 0;
   struct s  silly = {-1,-1};   
   struct s resu;
   if (b == 0) {
     return silly;
   }
   else
     {
  /*@
    loop invariant 
    ( a ==  b*qq + rr) &&
    rr >= 0;
    loop assigns rr,qq;
    loop variant rr;
   */
   while (rr >= b) { rr = rr - b; qq=qq+1;};
   resu.q= qq;
   resu.r = rr; 
  return resu;
}
}
   

