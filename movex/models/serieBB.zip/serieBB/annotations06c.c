/*@  assigns \nothing;
  @ ensures \result ==(x0+x0)*(x0+x0) ;

  @*/
int  ex(int x0,int y0,int z0) {
    int x=x0,y=x0,z=x0*x0;
  //@ assert l1: x == y && z == x*y;
  x = x*x;
  //@ assert l2: x == y*y && z == x;
  y = x;
    //@ assert l3:  x + y + 2*z == (x0+x0)*(x0+x0) ;
  z = x + y + 2*z;
 //@ assert z == (x0+x0)*(x0+x0);
  return(z);
}

