#include <limits.h>
#include "power3.h"
int power(int x)
{int  r, cz,cv,cu,cw,ct, k;
  cz=0;cv=0;cw=1;ct=3;cu=0;k=0;
  while (k<x)
	{
	  cz=cz+cv+cw;
	  cv=cv+ct;
	  ct=ct+6;
	  cw=cw+3;
	  cu=cu+1;
	  k=k+1;}
  r=cz;return(r);
}
