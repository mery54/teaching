void main(void){
  int x,y; 
  x = 1;
  x = x + 1;
  y = 2*x;
  x = x+y;
  /*@  assert x == 6; */
 
  }
