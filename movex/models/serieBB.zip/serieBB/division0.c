struct s  division(int a, int b) 
{  int rr = a;
   int qq = 0;
   /*@ loop invariant  b <= rr &  ;
        lopp assigns rr,qq;
    while (rr >= b) { rr = rr - b; qq=qq+1;};
   resu.q= qq;
   resu.r = rr; 
  return resu;
}
}
   

