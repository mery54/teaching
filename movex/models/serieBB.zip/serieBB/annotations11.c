/*@ requires  x0 == 64 && y0 == x0*z0  &&  z0==2*x0;
 */
void  ex61(int x0,int y0,int z0) {
  int x = x0,y=y0,z=z0;
  //@  assert l1: x == 64 && y == x*z &&  z==2*x;
  y = x*z;
  //@  assert l2:  y*z == 2*x*x*z;
}

