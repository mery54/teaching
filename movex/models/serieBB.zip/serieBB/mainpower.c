#include <stdio.h>
#include <limits.h>
int power(int x)
{int  r, cz,cv,cu,cw,ct, k;
  cz=0;cv=0;cw=1;ct=3;cu=0;k=0;
  while (k<x)
	{
	  printf("%d %d %d cz=%d %d\n",cu,cv,cw,cz,ct); 
	  cz=cz+cv+cw;
	  cv=cv+ct;
	  ct=ct+6;
	  cw=cw+3;
	  cu=cu+1;
	  k=k+1;}
    r=cz;
  return(r);
}

int p(int x)
{
  int r;
  if (x==0)
	{
	  r=0;
	  
	}
  else
	{
	  r= p(x-1)+3*(x-1)*(x-1) + 3*(x-1)+1;
	  
	}    
  return(r);
}



int check(int n){
  int r1,r2,r;
  r1 = power(n);
  r2 = p(n);
  if (r1 != r2)
    { r = 0;
    }
  else
    { r = 1;
    };
  return r;
 }



int main () {

  int counter;
    for( counter=0; counter<5; counter++ ) {
      int v,r;
      printf("Enter a natural number:");
      scanf("%d", &v);
      r = power(v);
      printf ("Power : %d ---->  %d\n", v,r);

    };
}
