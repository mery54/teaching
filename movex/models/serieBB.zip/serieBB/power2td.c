 #include <limits.h>
 #include <power2.h>
int power2(int x)
{int  r,k,cv,cw;
  r=0;k=0;cv=0;cw=0;
      /*@ loop invariant cv == k*k;
         @ loop invariant k  <= x;
         @ loop invariant cw  == 2*k;        
         @ loop invariant  4*cv  == cw*cw;
         @ loop assigns k,cv,cw;
      @ loop variant x-k;
*/
  while (k<x)
	{
	 k=k+1;
	  cv=cv+cw+1;
	  cw=cw+2;
	  
	}
  r=cv;
  return(r);
}
