      
/*@ 
  requires 0 <= n;
  ensures \result == n * n; 
*/
int f(int n) {
  int i = 0;
  //@ assert i==0;
  int s = 0;
  //@ assert  s == i*i && 0 <= i && i  <= n;  

  /*@ loop invariant i * i == s && 0 <= i && i <= n;
     @ loop assigns i, s;
   @ loop variant n-i; */
  while (i < n) {
    i++;
    s += 2 * i - 1;
  };
 //@ assert i==n && s == n*n;    
  return s;
}
