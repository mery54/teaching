#include <stdio.h>
#include <limits.h>
#include <math.h>

// Definition of the  mathematical function mathpower2
/*@ axiomatic mathpower {
  @ logic integer mathpower(integer n,integer m);
  @ axiom mathpower_0: \forall integer n; n >= 0 ==> mathpower(n,0) == 1;
  @ axiom mathpower_in: \forall integer n,m; n >= 0 && m >= 0 
  ==> mathpower(n,m+1) == mathpower(n,m)*n;
  @ } */

/*@  requires  0 <= x; 
     assigns \nothing;
     ensures \result + 1 == mathpower(2,x);
*/

int inv1(int x)
{ int u=0;
  int k=0;
      /*@ loop invariant u + 1  == mathpower(2,k);
         @ loop invariant 0 <= k && k  <= x;
         @ loop assigns k,u; 
          @ loop variant x-k; */
  
  while (k  < x)
    { u=2*u+1;
      k=k+1;
    };
  return(u);
    }

