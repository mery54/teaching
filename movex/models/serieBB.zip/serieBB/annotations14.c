void main(void){
  int x; 
  x = 1;
  x = x + 1;
  /*@  assert x == 2; */
 
  }
