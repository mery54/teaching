/*@ requires a >= 0 && b >= 0;
  ensures 0 <= \result;
  ensures \result < b;
  ensures \exists integer k; a == k * b + \result;
*/
int rem(int a, int b) {
  int r = a;

  && 
    ( a == i * b + r) &&
    r >= 0 && r <= a
    ;
    loop assigns r,i;
   */
  while (r >= b) {
    r = r - b;
    ++i;
  };
  return r;
}
