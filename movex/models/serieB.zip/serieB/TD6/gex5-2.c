
int q2() {
  int x=1,y=12;
//@ assert x== 1 && y == 12;
 x= 2*y;
  //@ assert  x== 1 && y == 24;
 return(0);
}


