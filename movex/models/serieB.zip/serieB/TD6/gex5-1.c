
int q1() {
  int x=10,y=30,z=20;
//@ assert x== 10 && y == z+x && z==2*x;
 y= z+x;
  //@ assert  x== 10 && y == x+2*10;
 return(0);
}

/*@ requires a== 10 && b == c+a && c==2*a;
 */

int q2(int a,int b,int c) {
  int x=a,y=b,z=c;
//@ assert x== 10 && y == z+x && z==2*x;
 y= z+x;
  //@ assert  x== 10 && y == x+2*10;
 return(0);
}
