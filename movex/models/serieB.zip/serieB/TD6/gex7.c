/*@ requires N > 0 && \valid(V+(0..N-1));
@ assigns \nothing;
@ ensures \result == \sum(0,N-1,\lambda integer i ; V[i]);  
*/
int exercice4(int V[], int S,int N){
  int I;
  S=V[0];
 //@ assert S==V[0];
  I=0;
 //@ assert S==V[0] && I == 0;
  /*@ loop invariant 0 <= I <= N;
    @ loop invariant S == \sum(0,I,\lambda integer i ; V[i]);  
   */  
  while (I<N) {
    //@ assert 0 <= I < N;
    //@ assert  S == \sum(0,I,\lambda integer i ; V[i]);
    //@ assert  0 <= I < N;
  S= S + V[I];
    //@ assert 0 <= I < N;
    //@ assert  S == \sum(0,I+1,\lambda integer i ; V[i]);
    //@ assert  0 <= I < N;  
  I= I +1;
    //@ assert 0 <= I < N;
    //@ assert  S == \sum(0,I,\lambda integer i ; V[i]);
    //@ assert  0 <= I < N;    
  }
 //@ assert S == \sum(0,N-1,\lambda integer i ; V[i]);  
  return(S);
}

