
int q2() {
  int x=11,y=13,z;
//@ assert x== 11 && y == 13;
z=x;x= y;y= z;\\
  //@ assert  x== 26/2 && y == 33/3;
 return(0);
}

