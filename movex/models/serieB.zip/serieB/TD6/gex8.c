/*@ lemma test: \forall integer a,b; (a+b)*(a+b)==a*a + 2*a*b + b*b;
 */

#include <limits.h>
/*@ 
 assigns \nothing;
@ ensures  n<b ==>\result == (n+b)*(n+b);
@ ensures  n >= b ==>\result == b;
*/

int exercice3(int n, int b, int x){
 x=n;
 //@ assert x == n;  
  if (x<b) {
 //@ assert x == n && x<b;      
    x= x*x + 2*b*x+b*b;
 //@ assert n<b &&  x == (n+b)*(n+b);
  }
  else
    {
 //@ assert x == n  && x>=b;      
      x=b;
 //@ assert n >= b  && x == b ;           
    };
 //@ assert n<b ==> x == (n+b)*(n+b);
 //@ assert n>=b ==>x == b;
  return(x);
}
  
