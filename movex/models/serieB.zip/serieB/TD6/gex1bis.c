// frama-c-gui -wp -wp-rte  -report -wp-print  maxpointer.c 

/*@ requires \valid(p)  && \valid(q); 
  assigns \nothing;
    ensures \result >= *p && \result >= *q; 
    ensures \result == *p || \result == *q;
*/
int max_ptr ( int *p, int *q ) {
  int r;
  if ( *p >= *q )
    { r = *p;}
  else
    { r = *q;};
  //@ assert r >= *p && r >= *q; 
  //@ assert r == *p || r == *q; 
  r == *q; 
return r ;
}
