
/*@
  requires x < 3 && x > 8;
  ensures \false;
*/
void fonc(int x){

}
