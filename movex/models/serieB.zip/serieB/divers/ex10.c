int max ( int x, int y ) {
  if ( x >=y ) return x ;
  return y ; }
