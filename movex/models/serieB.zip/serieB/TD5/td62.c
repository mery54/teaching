void ex(void) {
  int x0,y0,z0;
  int x=x0,y=x0,z=x0*x0;

  //@ assert x == y && z == x*y;
  x = x*x;
  //@ assert x == y*y && z == x;
  y = x;
  z = x + y + 2*z;
  
  //@ assert z == (x0+x0)*(x0+x0);
}

