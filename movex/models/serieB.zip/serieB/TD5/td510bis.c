int main()
{
  int z; 
  int a = 4;
  //@ assert a == 4 ;  
  int b = 3; 
  //@ assert   b == 3 && a == 4;    

   //@ assert b == 3 && a+b == 7 && a == 4 ;  
   //@ assert a+a+b == 11 && b+a+a+b == 14 && a+b == 7 &&  a+a+b +b+a+a+b  == 25 ;
  //@ assert  a+a+b == 11 && b+a+a+b == 14 && a+b == 7 && (a+a+b)*(b+a+a+b) == 154;  

  int c = a+b; 

  //@ assert a == 11 && b+a == 14 && a+b == 7 &&  a +b+a  == 25 ;
  //@ assert  a == 11 && b+a == 14 && a+b == 7 && a*(b+a) == 154;  

  
  a  = a +  c; 

  //@ assert a == 11 && b+a == 14 && c == 7 &&  a +b+a  == 25 ;
  //@ assert  a == 11 && b+a == 14 && c == 7 && a*(b+a) == 154;  

  b = b +  a;
  //@ assert a == 11 && b == 14 && c == 7 &&  a +b  == 25 ;
  //@ assert  a == 11 && b == 14 && c == 7 && a*b == 154;  
  z = a*b;
  //@ assert  a == 11 && b == 14 && c == 7 && z == 154;
  return(0);
}
    

    
