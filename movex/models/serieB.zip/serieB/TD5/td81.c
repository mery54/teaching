/*@ 
  requires x0==64 && y0==x0*z0 && z0==2*x0;
  ensures \result == 0;
*/
int  ex(int x0,int y0,int z0) {
  int x=x0,y=y0,z=z0;

  //@ assert x==64 && y==x*z && z==2*x;
  y = y*z;
  //@ assert  y*z ==  2*x*x*z;
  return 0;

  
}

