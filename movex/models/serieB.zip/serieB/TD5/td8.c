/*@ 
  requires x0==1 && y0==12;
  ensures \result == 0;
*/
int  ex(int x0,int y0) {
  int x=x0,y=y0;

  //@ assert x == 1 && y == 12;
  x = 2*y;
  //@ assert x == 24 && y == 12;
  return 0;

  
}

