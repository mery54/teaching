#include <limits.h>
// returns the maximum of x and y
/*@ 
    ensures \result >= x && \result >= y && \result==\max(x,y); */
int max ( int x, int y ) {
  int r;
  //@ assert x >= y ==> x>= y && x == \max(x,y);
  //@ assert x < y ==> x< y && y == \max(x,y);  
  if ( x >=y )
    {
        //@ assert  x>= y;
       //@ assert  x == \max(x,y);
       //@ assert  x == \max(x,y);            
      r=x ;
       //@ assert  r == \max(x,y);
       //@ assert  r == \max(x,y);      
    }
  else {
        //@ assert  x< y;
       //@ assert  y == \max(x,y);
       //@ assert  y == \max(x,y);          
  r =  y ;
       //@ assert  r == \max(x,y);
       //@ assert  r == \max(x,y);      
  };
       //@ assert  r == \max(x,y);      
  return r;
}
