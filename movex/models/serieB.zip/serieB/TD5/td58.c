#define v 3
/*@ requires  val == v; 
 */

int  exemple(int val)
{
  int c = val ; 
  //@ assert  c == 2; 
  int x; 
  //@ assert  c == 2;  
  x = 3 * c ; 
  //@ assert x == 6; 
  return(0);
}  
