#include <limits.h>
// returns the maximum of x and y
/*@ 
    ensures \result >= x && \result >= y; */
int max ( int x, int y ) {

  if ( x >=y )
    {
        //@ assert  x>= y;
      return x ;
       //@ assert  x>= y;      
    }
        //@ assert  x< y;  
  return y ;
        //@ assert  x< y;
}
