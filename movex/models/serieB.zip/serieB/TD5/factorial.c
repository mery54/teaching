/*@ axiomatic mathfact {
  @ logic integer mathfact(integer n);
  @ axiom mathfact_1: mathfact(1) == 1;
  @ axiom mathfact_rec: \forall integer n; n > 1 
  ==> mathfact(n) == n * mathfact(n-1);
  @ } */

/*@ requires n > 0;
  ensures \result == mathfact(n);
*/
int codefact(int n) {
  int y = 1;
  int x = n;
  /*@ loop invariant x >= 1 &&
                     mathfact(n) == y * mathfact(x);
    loop assigns x, y;
    loop variant x-1;
   */
  while (x != 1) {
    y = y * x;
    x = x - 1;
  };
  return y;
}


/*@ requires n > 0;
  ensures \result == mathfact(n);
*/
int f(int n) {
  if (n == 1) {
    return 1;
  }
  else
{
  return n*f(n-1);

 };

  }



/*@ requires n > 0; ensures \result == 1;
*/

int check(int n){
  int r1,r2,r;
  r1 = codefact(n);
  r2 = f(n);
  if (r1 == r2)
    { r = 1;
    }
  else
    { r = 0;
    };
  return r;
 }


