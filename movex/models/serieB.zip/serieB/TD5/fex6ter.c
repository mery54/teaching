#include <limits.h>

/*@ 
  requires 0 <= n;
  requires  n*n <= INT_MIN;
  assigns \nothing;
  ensures \result == n * n; 
*/
int f(int n) {
  int i = 0;
  //@ assert i==0;
  int s = 0;
  /*@ loop invariant i * i == s && i <= n;
    @ loop assigns i, s; 
  @ loop variant n-i;
*/
  while (i < n) {
    s += 2 * i + 1;
     i++;

  };
  return s;
}
