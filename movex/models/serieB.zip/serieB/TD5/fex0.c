void ex(void) {
  int x=0,y=3;

  //@ assert x + y == 2 ;
  x = x+3;
  //@ assert x +y == 6;
  y = y+2;
  //@ assert x+y == 8;
}

