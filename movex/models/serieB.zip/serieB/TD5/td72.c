    /*@ 
  requires  z0 == 25 ;
  ensures \result == 26; 
*/
int f(int z0) {
    int z = z0; 
    /*@ assert   z == 25 ;*/    
   z = z+1;
/*@ assert  z == 26 ; */    
  return z; 
}
