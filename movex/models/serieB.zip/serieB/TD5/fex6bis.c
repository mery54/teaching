   
/*@ 
  requires 0 <= n;
  assigns \nothing;
  ensures \result == n * n; 
*/
int f(int n) {
  int i = 0;
  //@ assert i==0;
  int s = 0;
  /*@ loop invariant i * i == s && i <= n;
    @ loop assigns i, s; */
  while (i < n) {
    s += 2 * i + 1;
     i++;

  };
  return s;
}
