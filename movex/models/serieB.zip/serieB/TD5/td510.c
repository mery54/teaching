int main()
{
  int z; 
  int a = 4;
  //@ assert a == 4 ;  
  int b = 3; 
  //@ assert   b == 3 && a == 4;    
  int c = a+b; 
  //@ assert b == 3 && c == 7 && a == 4 ;  
  a += c; 
  b += a;
  //@ assert a == 11 && b == 14 && c == 7 ;
  //@ assert a +b  == 25 ;  
  z = a*b;
  //@ assert  a == 11 && b == 14 && c == 7 && z == 154;
  return(0);
}
    
