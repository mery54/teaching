/*@ requires x0 >= 0 && y0 >= 0; 
  @ ensures (\result == x0 || \result == y0)  && \result >= x0 && \result >= y0;
  */

 exemple(int x0,int y0)
{
  int x=x0;
  int y=y0;
  int z;
//@  assert  x == x0  && y == y0;   
  if ( x < y )
    {
    z = y;
    }
  else
    {
    z=x;
    };
   return z;
}  
