
void ex(void) {

  //@ assert 2 <= 4;
  //@ assert 2*2 == 1*4 &&  2*2+2*2*2 == 2*2+2*2*2 && 2*2* 2*2*2 >= 8;
  
  int x=2,y=4,z,a=1;

  //@ assert x <= y;
  //@ assert x*x == a*y &&  x*x+2*x*x == x*x+2*x*x && x*x* 2*x*x >= 8;    
  x = x*x;
  //@ assert x == a*y &&  x+2*x == x+2*x && x* 2*x >= 8;  
  y = 2*x;

    //@ assert  x+y  == x+y && x* y >= 8;
  
  z = x + y;
  
  //@ assert z == x+y && x* y >= 8;
}

