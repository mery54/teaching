void ex(void) {
  int x=-1,y=-1;

  //@ assert x + y == -2 ;
  x = x+3;
  //@ assert x +y == 1;
  y = y+2;
  //@ assert x+y == 3;
}

