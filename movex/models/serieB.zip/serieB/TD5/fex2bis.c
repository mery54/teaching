void ex(void) {
  int x=2,y=4,z,a=1;

  //@ assert x <= y;
  //@ assert x *x == a*y;
    //@ assert x*x+2*x*x  == x*x+2*x*x && 2*x*x*y >= 8;  
  x = x*x;
  //@ assert x == a*y;
    //@ assert x+2*x  == x+2*x && 2*x*y >= 8;
  y = 2*x;

  //@ assert x+y  == x+y && x* y >= 8;
  
  z = x + y;
  
  //@ assert z == x+y && x* y >= 8;
}

