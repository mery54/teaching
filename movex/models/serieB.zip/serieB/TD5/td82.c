/*@ 
  requires x0==3^n && y0==3^p && z0==3^m;
  ensures \result == 0;
*/
int  ex(int x0,int y0,int z0,int m,int n) {
  int x=x0,y=y0,z=z0;

  //@ assert x== 3^n && y==3^p && z==3^m;
  t  = 8*x*y*z; 
  //@ assert   t == (y+z)^3 && y==x;
  return 0;

  
}

