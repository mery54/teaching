#include <limits.h>
// returns the maximum of x and y
/*@ 
    ensures \result >= x && \result >= y;
    ensures \result == x || \result == y;
 */
int max ( int x, int y ) {

        //@ assert  x<y ==> x< y;
        //@ assert x>= y ==>  x>= y;

  if ( x >=y )
    {
        //@ assert  x>= y;
        //@ assert  x>= y;      
      return x ;  // === \result = x!
       //@ assert  x>= y;      
    }
        //@ assert  x< y;
        //@ assert  x< y;  
  return y ; // === \result = y!
        //@ assert  x< y;
}
