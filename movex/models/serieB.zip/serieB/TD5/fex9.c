void ex(void) {
  int x=,y=;

  //@ assert x + y == 3 ;
  x = x+3;
  //@ assert x +y == 1;
  y = y+2;
  //@ assert x+y == 3;
}

