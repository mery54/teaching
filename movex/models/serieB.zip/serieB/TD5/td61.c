
void ex(void) {
  int x=2,y=4,z,a=1;

  //@ assert x <= y;
  x = x*x;
  //@ assert x == a*y;
  y = 2*x;
  
  z = x + y;
  
  //@ assert z == x+y && x* y >= 8;
}

