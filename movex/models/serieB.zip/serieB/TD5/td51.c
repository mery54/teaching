struct data {
    unsigned x;
    unsigned y;
    unsigned z;
};

/*@  
  @ ensures \result.z == 100 && \result.x+\result.y == 12 && \result.x + x0==4;
  */


struct data  exemple(int x0,int y0,int z0)
{
  int x=x0;
  int y=y0;
  int z=z0;
//@  assert  x == x0;   
  x = x + 1;
  y=x+y+2;					\
  z = x +y;
  struct data r;
  r.x = x;r.y=y;r.z=z;
  return r;
}  
