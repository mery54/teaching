/*@
  assigns  \nothing;
*/
void swap1(int a, int b) {
  int x = a;
  int y = b;
  //@ assert x == a && y == b;
  // ==> ?
  //@ assert y == b && x == a;      
  int tmp;
  //@ assert y == b && x == a;      
  tmp = x;
  //@ assert y == b && tmp == a;    
  x = y;
  //@ assert x == b && tmp == a;  
  y = tmp;
  //@ assert x == b && y == a;
}
  
