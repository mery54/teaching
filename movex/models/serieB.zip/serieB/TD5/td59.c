int  exemple()
{
  int a = 42; int b = 37; 
  int c = a+b; 
l1:  b == 37 ;  
  a -= c;
  b += a;
l2:  b == 0 && c == 79; 
  return(0);
}
