    /*@ 
  requires x0>=0 && y0 >= 0 && z0 >= 0 && z0 == 25 &&  y0==x0+1 &&
 x0*x0 + y0*y0 == z0 &&    z0 == 25  &&  (x0+3)*(x0+3) + (y0+4)*(y0+4) == z0+75 ;
  ensures \result == 100; 
*/
int f(int x0,int y0,int z0) {
  int x = x0;
  int y = y0;
    int z = z0; 
/*@ assert  x*x + y*y == z &&    z == 25 ;*/
/*@ assert  (x+3)*(x+3) + (y+4)*(y+4) == z+75 ; */            
   x = x +3;
/*@ assert  x*x + (y+4)*(y+4) == z+75 ; */        
y = y +4;
/*@ assert  x*x + y*y == z+75 ; */     
z = z + 75;
/*@ assert  x*x + y*y == z ; */    
  return z; 
}
