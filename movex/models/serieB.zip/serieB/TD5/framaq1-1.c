/*@ axiomatic power {
  @ logic integer power(integer m,integer n);
  @ axiom power_1: \forall integer m; m > 0 
  ==> power(m,0) == 1;
  @ axiom power_rec: \forall integer m; m > 0 ==> 
  \forall integer n; n > 0 
  ==> power(m,n) == m * power(m,n-1);
  @ lemma p1: power(2,6)==64;
  @ lemma p2: power(2,6)*power(2,7)==power(2,13);
  @ lemma p3: \forall integer m; m >= 0 ==> 2*power(2,m)==power(2,m+1);
  @} */
#define p 6
int main(void){
  signed long int x=32,z=2*x,y=2*z*x;
  /*@ assert x == 32  && y==2*x*z && z==2*x; */      
  y = x*z;
  /*@  assert  y*z ==  2*x*x*z;     */        
  return 0;
  }
