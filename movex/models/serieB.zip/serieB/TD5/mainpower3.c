#include <stdio.h>
#include <math.h>



int power3(int x)
{int  r,ocz,cz,cv,cu,ocv,cw,ocw,ct,oct,ocu,k,ok;   
  cz=0;cv=0;cw=1;ct=3;cu=0; ocw=cw;ocz=cz;
  oct=ct;ocv=cv;ocu=cu;k=0;ok=k;
  while (k<x)
	{
	  ocz=cz;ok=k;ocv=cv;ocw=cw;oct=ct;ocu=cu;
	  cz=ocz+ocv+ocw;
	  cv=ocv+oct;
	  ct=oct+6;
	  cw=ocw+3;
	  cu=ocu+1;
	  k=ok+1;}
  r=cz;return(r);}

int p(int x)
{
  int r;
  if (x==0)
	{
	  r=0;
	  
	}
  else
	{
	  r= p(x-1)+3*(x-1)*(x-1) + 3*(x-1)+1;
	  
	}    
  return(r);
}

int check(int n){
  int r1,r2,r;
  r1 = power3(n);
  r2 = p(n);
  if (?? == ??)
    { r = ??;
    }
  else
    { r = ??;
    };
  return r;
 }
int main()
{
  int val1,val2,val3,num;
   printf("Enter a number: ");
   scanf("%d", &num);
   // Computes the square root of num and stores in root.
   val1 = power3(num);
     val2 = p(num);
     val3 = check(num);
     printf("Et le résultat  pour n= %d: %d %d %d\n", num, val1,val2,val3);
   return 0;
}
