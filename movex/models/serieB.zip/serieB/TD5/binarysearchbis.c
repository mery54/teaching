#include <stdio.h>

/*@ requires n > 0 && \valid(a+(0..n-1));
@ requires \forall integer i,j; 0 <= i &&  i <= j && j < n ==> a[i] <= a[j];
@ assigns \nothing;
@ ensures -1 <= \result <= n-1;
@ ensures \result == -1 ==>  \forall integer k; 0<=k<n ==> a[k] != element;
@ ensures \result != -1 ==>   a[\result] == element;
*/

int iterativeBinarySearch(int a[], int n,int element){
  int left = 0;int right=n-1,r;
 /*@ loop invariant 0 <= left <=right+1 ;
   @ loop invariant right < n;
    @ loop assigns left,right;
    @  loop invariant  \forall integer i;  0 <= i && i <= left-1==> element > a[i];
    @  loop invariant  \forall integer i;right+1 <= i<=n-1 ==> element < a[i]; 
    @ loop variant right - left;
 */

  while (left <= right){
       int middle = left + (right- left )/2;
       if (a[middle] == element){
 	return middle;
      };
      if (a[middle] < element){
          left = middle + 1;
       }	      
      else
	{
 	  
         right = middle - 1;
 	 
	};
   }
  r = -1;
   return r;
}

/*@ requires 0<= l<= r && \valid(a+(0..r));
@ requires \forall integer i,j; 0 <= i &&  i <= j && j <= r ==> a[i] <= a[j];
@ assigns \nothing;
@ ensures  l <= \result <= r || \result == -1;
@ ensures \result == -1 ==>  \forall integer k; l<=k<=r ==> a[k] != x;
@ ensures \result != -1 &&  l<= \result<=r ==>   a[\result] == x;
*/

int binarySearchdm(int a[], int l, int r, int x)
{
  if (x < a[l] || x > a[r] )
    { return -1;
      }
  else {
    
      
  if (l <= r)
{
int mid = l + (r - l)/2;

if (a[mid] == x) return mid;

if (a[mid] > x) return binarySearchdm(a, l, mid-1, x);

return binarySearchdm(a, mid+1, r, x);
}

 else
   {
// We reach here when element is not present in array
     return -1;};
  }
}



/*@ requires n > 0 && \valid(a+(0..n-1));
@ requires \forall integer i,j; 0 <= i &&  i <= j && j < n ==> a[i] <= a[j];
@ requires  a[0] <= x <=  a[n-1];
@ assigns \nothing;
@ ensures  \result == 1;
*/

int check(int a[],int n,int x)
{
  int r,val1,val2;
   val1 = iterativeBinarySearch(a, n,x);
   val2 = binarySearchdm(a,0,n-1,x);   
  if (a[val1] == a[val2])
    { r = 1;
    }
  else
    { r = 0;
    };
  return r;
 }

