
int main()
{
  int a = 4;
  int b = 3;
  int c = a+b; 
  a += c; 
  b += a;
  //@ assert a == 11 && b == 14 && c == 7 ;
  return(0);
}
