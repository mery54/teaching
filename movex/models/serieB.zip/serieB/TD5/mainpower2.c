#include <stdio.h>
#include <math.h>

int power2(int x)
{int  r,k,cv,cw,or,ok,ocv,ocw;
  r=0;k=0;cv=0;cw=0;or=0;ok=k;ocv=cv;ocw=cw;
  while (k<x)
	{
	  ok=k;ocv=cv;ocw=cw;
	  k=ok+1;
	  cv=ocv+ocw+1;
	  cw=ocw+2;
	  
	}
  r=cv;
  return(r);
}

int p(int x)
{
  int r;
  if (x==0)
	{
	  r=0;
	  
	}
  else
	{
	  r= p(x-1)+2*x-1;
	  
	}    
  return(r);
}

int check(int n){
  int r1,r2,r;
  r1 = power2(n);
  r2 = p(n);
  if (?? == ??)
    { r = ??;
    }
  else
    { r = ??;
    };
  return r;
 }
int main()
{
  int val1,val2,val3,num;
   printf("Enter a number: ");
   scanf("%d", &num);
   val1 = power2(num);
     val2 = p(num);
     val3 = check(num);
     printf("Et le résultat  pour n= %d: %d %d %d\n", num, val1,val2,val3);
   return 0;
}
