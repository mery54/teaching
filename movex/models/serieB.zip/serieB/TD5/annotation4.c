/*@ requires a >= 0 ;
  @ assigns \nothing;
  @ ensures \result == 0;
  @*/
int annotation(int a)
{
  int x;
  x = a;
  return(x);
  
  }
