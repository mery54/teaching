#include <limits.h>
// returns the maximum of x and y
/*@ 
    ensures \result >= x && \result >= y && (\result == x || \result == y);
 */
int max ( int x, int y ) {

    //@ assert   x< y  => y >= x && y >= y && (y == x || y == y);
  //@ assert  x>= y => x >= x && x >= y && (x == x || x == y);                
  if ( x >=y )
    {
        //@ assert  x>= y;
       //@ assert  x>= y;
  //@ assert x >= x && x >= y && (x == x || x == y);              
      return x ;
       //@ assert  x>= y;
  //@ assert \result >= x && \result >= y && (\result == x || \result == y);        
    };
    //@ assert  x< y;
    //@ assert  x< y;
  //@ assert y >= x && y >= y && (y == x || y == y);   
  return y ;
   //@ assert  x< y;
  //@ assert \result >= x && \result >= y && (\result == x || \result == y);  
}
