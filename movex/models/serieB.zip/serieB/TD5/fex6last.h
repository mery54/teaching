#include <limits.h>

/*@ 
  requires 0 <= n;
  requires  n*n <= INT_MIN;
  assigns \nothing;
  ensures \result == n * n; 
*/
int f(int n);

