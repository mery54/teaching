#include <limits.h>
// returns the maximum of x and y
/*@ 
    ensures \result >= x && \result >= y; */
int max ( int x, int y ) {
  int r;
  if ( x >=y )
    {
        //@ assert  x>= y;
      r=x ;
       //@ assert  r == \max(x,y);      
    }
  else {
        //@ assert  x< y;  
  r =  y ;
       //@ assert  r == \max(x,y);      
  };
       //@ assert  r == \max(x,y);      
  return r;
}
