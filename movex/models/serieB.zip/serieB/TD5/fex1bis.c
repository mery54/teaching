void ex(void) {
  int x0,y0,z0;  
  int x=x0,y=x0,z=x0*x0;

  //@ assert x == y && z == x*y;
  //@ assert x*x == y*y && z == x*x;
  //@ assert x*x + x*x + 2*z == (x0+x0)*(x0+x0);  
  x = x*x;
  //@ assert x == y*y && z == x;
  //@ assert x + x + 2*z == (x0+x0)*(x0+x0);
  y = x;
  //@ assert x + y + 2*z == (x0+x0)*(x0+x0);
  z = x + y + 2*z;
  //@ assert z == (x0+x0)*(x0+x0);
}

