-------------------------------- MODULE malgtd1ex2 --------------------------------
(* modules de base importables *)
EXTENDS Naturals,TLC 
----------------------------------------------------------------------------
CONSTANTS max
----------------------------------------------------------------------------
VARIABLES  np
-----------------------------------------------------------------------------
(*  tentative 1 *)
entrer == np'=np +1
sortir == np'=np-1
Next == 
     \/ entrer 
     \/ sortir
Init == np=0
test == [] (0 \leq np  /\ np \leq max)
-----------------------------------------------------------------------------
(* tentative 2 *)

sortir2 == np>0 /\ np'=np-1 
next2 ==  entrer \/  sortir2


entrer2 == np<max /\ np'=np+1 
next3 ==  entrer2  \/  sortir2
-------------------------------------
------------------
safety1 == np \leq max \* ok
safety2 == 0 \leq np \* ok
question1 ==  np # max 
safety  == safety1 /\ safety2
=============================================================================
