-------------------------------- MODULE malgtd1ex10ter --------------------------------

EXTENDS Naturals, Integers,TLC
CONSTANTS x0,y0
\* VARIABLES  x,y,pc
------------------------------------------------------------------------------
----------------------------------------------------------------------------
(* Auxiliary definitions *)
typeInt(u) == u \in Int
pre(u,v) == /\ typeInt(u) /\ typeInt(v) 
             /\  u=1 /\ v=12
---------------------------------------------------------------------
(* Interpretation: w assume that the precondition can hold and we have to find possible values for x0,y0, z0 to validate or not *)
ASSUME pre(x0,y0)
-----------
(*

--algorithm truc {
variables x=1,y=12;
{
 l1: assert  x=1 /\ y =12;
y := x+1;
x := 2*y+x;
 l2: assert x=1 /\ y = 25;
}
}
*)
\* BEGIN TRANSLATION (chksum(pcal) = "5dfa9272" /\ chksum(tla) = "5f3eeadf")
VARIABLES x, y, pc

vars == << x, y, pc >>

Init == (* Global variables *)
        /\ x = 1
        /\ y = 12
        /\ pc = "l1"

l1 == /\ pc = "l1"
      /\ Assert(x=1 /\ y =12, "Failure of assertion at line 21, column 6.")
      /\ y' = x+1
      /\ x' = 2*y'+x
      /\ pc' = "l2"

l2 == /\ pc = "l2"
      /\ Assert(x=1 /\ y = 25, "Failure of assertion at line 24, column 6.")
      /\ pc' = "Done"
      /\ UNCHANGED << x, y >>

(* Allow infinite stuttering to prevent deadlock on termination. *)
Terminating == pc = "Done" /\ UNCHANGED vars

Next == l1 \/ l2
           \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")

\* END TRANSLATION 






(* Action for transitioon of the algorithm *)
al1l2 ==
    /\ pc="l1"
    /\ pc'="l2"
    /\ x'=2*y+x
    /\ y'=y
---------------------------------------------------------------
(* Computations *)
Next2 == al1l2  \/ UNCHANGED <<x,y,pc>>
Init2 == pc="l1" /\ x=x0 /\ y =y0  /\ pre(x0,y0)
----------------------
(* Checking the annotation by checking the invariant i derived from the annotation *)
i ==
    /\ typeInt(x) /\ typeInt(y) 
    /\ pc="l1" =>  x=x0 /\ y=y0 /\ pre(x0,y0)
    /\ pc="l2" =>  x=1 /\ y =  25

safe ==  i

=============================================================================
\* Modification History
\* Last modified Mon Mar 10 10:50:41 CET 2025 by mery
\* Created Wed Sep 09 18:19:08 CEST 2015 by mery
