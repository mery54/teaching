--------- MODULE tla_squareroot --------
EXTENDS Integers,TLC
CONSTANTS x,U (* x is the input *)
VARIABLES  pc,y1,y2,y3,z
--------------------------------------------------------------
vars == <<pc,y1,y2,y3,z>>
--------------------------------------------------------------
al0l1 == pc="l0" /\ y1'=0 /\y2'=1 /\ y3'=1 /\ pc'="l1" /\ z'=z /\ x'=x
al1l2 == pc="l1" /\ y2 \leq x /\pc'="l2" /\  UNCHANGED <<y1,y2,y3,z,x>>
al1l4 == pc="l1" /\ y2 >  x /\ pc'="l4" /\ UNCHANGED <<y1,y2,y3,z,x>>
al2l3 == pc="l2" /\ y1'=y1+1 /\y2'=y2+y3+2 /\ y3'=y3+2 /\ pc'="l3" /\ z'=z /\ x'=x
al3l2 == pc="l3" /\ y2 \leq x /\pc'="l2" /\  UNCHANGED <<y1,y2,y3,z,x>>
al3l4 == pc="l3" /\ y2 >  x /\ pc'="l4" /\ UNCHANGED <<y1,y2,y3,z,x>>
al4l5 == pc="l4" /\ z'=y1 /\pc'="l5" /\  UNCHANGED <<y1,y2,y3,x>>
--------------------------------------------------------------
Init == y1=U /\ y2 = U /\ y3 = U /\ z=U /\ pc="l0"
Next == al0l1 \/ al1l2 \/ al1l4\/ al2l3 \/ al3l2 \/ al3l4 \/ al4l5   
--------------------------------------------------------------
MAX == 32767  (* 16 bits *)
MIN == -32768
D == MIN..MAX
(*  x \leq 32760 *)
Safety_absence ==  (y1 \in D)  /\ (y2 \in D) /\ (y3  \in D) /\ (z \in D)
i ==
	/\ pc="l0" => y1 \in D  /\  y2 \in D /\  y3 \in D /\  z \in D
	/\ pc="l1" => y2 = (y1+1)*(y1+1) /\ y3=2*y1+1  /\  y1*y1\leq x 
	/\ pc="l2" => y2 = (y1+1)*(y1+1) /\ y3=2*y1+1  /\  y1*y1\leq x /\ y2 \leq x   
	/\ pc="l3" => y2 = (y1+1)*(y1+1) /\ y3=2*y1+1  /\  y1*y1\leq x 
	/\ pc="l4" => y2 = (y1+1)*(y1+1) /\ y3=2*y1+1  /\  y1*y1\leq x /\ x < y2 
	/\ pc="l5" => y2 = (y1+1)*(y1+1) /\ y3=2*y1+1  /\  z*z\leq x /\ x < (z+1)*(z+1)  
Safety_partialcorrectness == pc="l5" => z*z\leq x /\ x < (z+1)*(z+1)

Qtermination == pc # "l5"

=========