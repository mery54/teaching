/*@ requires \false;
  @assigns \nothing;
  @ ensures \false;
  */  
int f1(int x)
{ if (f1(x) == 0)
    { return(1);
    }
  else
    { return(0);
    }
}

