#include <stdio.h>
#include <math.h>


int f1(int x)
{ if (f1(x) == 0)
    { return(1);
    }
  else
    { return(0);
    }
}


int main()
{
  int val,num;
   printf("Enter a number: ");
   scanf("%d", &num);
   // Computes something ?
   val = f1(num);
   printf(".... f1(%d)=%d\n", num, val);
   return 0;
}


