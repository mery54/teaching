/*@ requires \false;
  @ ensures \false;
*/  
int f2(int x)
{ if (f2(x) == 0)
    { return(0);
    }
  else
    { return(1);
    }
}
