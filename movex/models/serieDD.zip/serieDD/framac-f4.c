/*@ requires x <= 0;
   @ decreases -x;
  @assigns \nothing;

  @ ensures \result == 1;

  */  
int f4(int x)
{ if (x == 0)
    { return(1);
    }
  else
    { return(f4(x+1));
    }
}

