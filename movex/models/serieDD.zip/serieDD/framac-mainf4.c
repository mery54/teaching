#include <stdio.h>
#include <math.h>


int f4(int x)
{ if (x == 0)
    { return(1);
    }
  else
    { return(f4(x+1));
    }
}



int main()
{
  int val,num;
   printf("Enter a number: ");
   scanf("%d", &num);
   // Computes something ?
   val = f4(num);
   printf(".... f4(%d)=%d\n", num, val);
   return 0;
}


