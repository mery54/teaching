#include <stdio.h>
#include <math.h>


int f2(int x)
{ if (f2(x) == 0)
    { return(0);
    }
  else
    { return(1);
    }
}


int main()
{
  int val,num;
   printf("Enter a number: ");
   scanf("%d", &num);
   // Computes something ?
   val = f2(num);
   printf(".... f2(%d)=%d\n", num, val);
   return 0;
}


