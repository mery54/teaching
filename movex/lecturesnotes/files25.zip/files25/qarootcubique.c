struct paire {
    unsigned r;
    unsigned p;
};



struct paire f(int x)
{int  cz,cv,cu,cw,ct, k,ocz;
  struct paire r;
  cz=0;cv=0;cw=1;ct=3;cu=0;k=0;ocz=-1;
  while (cz<=x)
	{
	  ocz = cz;
	  cz=cz+cv+cw;
	  cv=cv+ct;
	  ct=ct+6;
	  cw=cw+3;
	  cu=cu+1;
	  k=k+1;}
  r.r=k-1;r.p=ocz;
 return(r);}

