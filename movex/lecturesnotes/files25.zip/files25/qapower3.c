#include <limits.h>
/*@  requires  0 <= x; 
     ensures \result ==x*x*x;
*/
int power3(int x)
{int  r,ocz,cz,cv,cu,ocv,cw,ocw,ct,oct,ocu,k,ok;   
  cz=0;cv=0;cw=1;ct=3;cu=0; ocw=cw;ocz=cz;
  oct=ct;ocv=cv;ocu=cu;k=0;ok=k;
       /*@ 
         @ loop invariant cu  == k;
         @ loop invariant ct == 6*cu +3;
         @ loop invariant cv== 3*cu*cu;
         @ loop invariant cw == 3*cu+1;
	 @ loop invariant cz == k*k*k;
         @ loop invariant k  <= x;
	 @ loop invariant 6*cw == 3*ct-3;
         @ loop assigns ct,oct,cu,ocu,cz,ocz,k,cv,ocv,cw,ocw,r,ok;
         @ loop assigns ocv,ocw;
          @ loop variant x-k;
*/
  while (k<x)
	{
	  ocz=cz;ok=k;ocv=cv;ocw=cw;oct=ct;ocu=cu;
	  cz=ocz+ocv+ocw;
	  cv=ocv+oct;
	  ct=oct+6;
	  cw=ocw+3;
	  cu=ocu+1;
	  k=ok+1;}
  r=cz;return(r);}
