/*@ requires  A(x,y,z) ;
  ensures \result == 49 ; 
*/

int q6(int x,int y, int z){

   z = y*(x+y);
   y = x*y;
   x=x*x;
   z = z+x+y;
/*@  assert  z == 49; */
  
  return z;
  }



