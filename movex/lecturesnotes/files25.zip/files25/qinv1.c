#include <limits.h>
#include <qmathinv1.h>

int inv1(int x)
{ int u=0;
  int k=0;
   while (k  < x)
    { u=2*u+1;
      k=k+1;
    };
  return(u);
    }

