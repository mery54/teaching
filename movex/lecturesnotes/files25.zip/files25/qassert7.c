/*@ requires  A(x,y,z);
  ensures \result == 144 ; 
*/

int q6(int x,int y, int z){
  int  u;
  u = x+y+z;
  x=x*x;
  /*@ assert  x == 9;*/
  y=y*y;
 /*@ assert  y == 16;*/  
  z=z*z;
  u = u*u;
    return u;
  }



