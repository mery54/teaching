#include <stdio.h>
#include <limits.h>


int ffS(int x)
{int  r,k,cv,cw,or,ok,ocv,ocw;
  r=0;k=0;cv=0;cw=0;or=0;ok=k;ocv=cv;ocw=cw;
  while (k<x)
    {
    ok=k;ocv=cv;ocw=cw;
      k=ok+1;
      cw=ocw+2;     
      cv=ocv+ocw+1;
     }
  r=cv;
  return(r);
}

int fS(int x) 
{int r=0,k=0,cv=0,cw=0;
  while (k<x)
    {
       k=k+1;
      cw=cw+2;       
      cv=cv+cw+1;
    }
  r=cv;
  return(r);
}

int main()
{
  for (int i = 0; i < 11; ++i){
    printf("La valeur de la fonction  pour  z=%d  est  %d    et on devrait obtenir %d\n",i,fS(i),i*i);}
     return 0;
}
