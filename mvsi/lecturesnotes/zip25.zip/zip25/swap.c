#include <stdio.h>
#include <limits.h>
// ******************************************************************
int ffS(int x,int y)
{int a,b,c,oa,ob,oc,r; 
  a=x;b=y;oa=a;ob=b;oc=c;
  a=ob;
  b=oa;
  r=(a == y && b == x);
  return(r);
}
// ******************************************************************
int fS(int x,int y)
{
  int a,b,c,r; 
  a=x;b=y;
  a=b;
  b=a;
  r=(a == y && b == x);
  return(r);
}
// ******************************************************************
int main()
{int x,y;


  

  for (int i = 0; i < 11; ++i){
    x=i;
    y=i+1;
    int a,b,c,r,oa,ob; 
    a=x;b=y;oa=a;ob=b;
  a=ob;
  b=oa;
  r=(a == y && b == x);
  printf("La valeur de la fonction  pour  x=%d  et y=%d  est  a=%d  et b=%d \n",x,y,a,b);}

  printf("\n");  printf("\n");  printf("\n");
// ******************************************************************
  for (int i = 0; i < 11; ++i){
    x=i;
    y=i+1;
    int a,b,c,r; 
  a=x;b=y;
  a=b;
  b=a;
  r=(a == y && b == x);
  printf("La valeur de la fonction  pour  x=%d  et y=%d  est  a=%d  et b=%d \n",x,y,a,b);}
     return 0;
}
