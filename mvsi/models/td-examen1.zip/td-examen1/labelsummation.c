  int ps = 0;
  int k = 0;
int r; 
 inloop: while (k < x) {
      k = k + 1;
      
    ps = ps + k+1;
  };
 outloop:  r = ps ;

