#include <stdio.h>

int ffS(int n) {
  int ps = 0;
  int k = 0;
  int ok=k, ops = 0;
  while (k < n) {
    ok=k;ops=ps;
    k = ok + 1;
    ps = ops + k;
  };
  return ps;
}
int fS(int n) {
  int ps = 0;
  int k = 0;
    while (k < n) {
      k = k + 1;
      
    ps = ps + k+1;
  };
  return ps;
}

int main()
{


  for (int i = 0; i < 11; ++i){
    printf("Value for z=%d is %d\n",i,fS(i));}
     return 0;
}
