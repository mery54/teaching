----------------------------- MODULE disapp_td2_ex2 -----------------------------
(* Communication  of  a list of values  and summation *)
EXTENDS Integers,Naturals,TLC
CONSTANT Nmax,U

T0 ==  {<<"data",12>>, <<"data",7>>, <<"data",0>>}
VARIABLES T,V_P1,V_P2,Mutex_READ_P1,Mutex_READ_P2,S
------------------------------------------------------------------------------------------
(* Auxiliary definitions *)

f == [i \in Nat |-> i+3 ]
MyNat == 0..Nmax
------------------------------------------------------------------------------------------
(* Definitions of actions *)

READ_P1 == 
    /\ \E w \in MyNat : <<"data",w>> \in T
    /\ Mutex_READ_P1 = "ko"
    /\ UNCHANGED <<Mutex_READ_P2,V_P2,S,V_P2>>
   \* soit v une valeur choisie dans l'ensemble T de la forme <<"data",val>>
    /\ LET val_p1 == CHOOSE v \in MyNat :  (<<"data",v>> \in T)
        IN
            /\ V_P1'=val_p1
            /\ Mutex_READ_P1' = "ok"
            \* on supprime l'element de notre ensemble T
            \* attention on cr�e un ensemble  avec les {} que on intersect avec T
            /\ T' = T \ {<<"data",val_p1>>}
    
COMP_P1 == 
    /\ Mutex_READ_P1 = "ok"
    /\ UNCHANGED <<Mutex_READ_P2,V_P1,V_P2,S>>
    /\ Mutex_READ_P1'= "ko"
    \* () op�rateur [] fonction
    /\ T'=T \union {<<"out",f[V_P1]>>}

READ_P2 == 
    /\ \E w \in MyNat : <<"out",w>> \in T
    /\ Mutex_READ_P2 = "ko"
    /\ UNCHANGED <<Mutex_READ_P1,V_P1,S,V_P1>>
   \* soit v une valeur choisie dans l'ensemble T de la forme <<"data",val>>
    /\ LET val_p2 == CHOOSE v \in MyNat :  /\ (v \in MyNat) /\ (<<"out",v>> \in T)
        IN
            /\ V_P2'=val_p2
            /\ Mutex_READ_P2' = "ok"
            \* on supprime l'element de notre ensemble T
            \* attention on cr�e un ensemble  avec les {} que on intersect avec T
            /\ T' = T \ {<<"out",val_p2>>}

COMP_P2 == 
    /\ Mutex_READ_P2 = "ok"
    /\ UNCHANGED <<Mutex_READ_P1,V_P1,V_P2>>
    /\ Mutex_READ_P2'= "ko"
    /\ S' = S + V_P2
    /\ T'=(T \ {<<"somme",S>>}) \union {<<"somme",S'>>}  
    
    
--------- --------- --------- --------- --------- --------- --------- 
(* Defining initial condition and the next relation *)

Init == 
	/\ Mutex_READ_P1 = "ko" /\ Mutex_READ_P2 = "ko" 
	/\ T = T0 /\ V_P1 = U /\ V_P2 = U
	/\ S = 0


SKIP == UNCHANGED <<T,V_P1,V_P2,Mutex_READ_P1,Mutex_READ_P2,S>>
Next == COMP_P1 \/ COMP_P2 \/ READ_P2 \/ READ_P1  \/ SKIP

test ==  T # {} => (\E v \in 0..Nmax: <<"data",v>> \in T \/ <<"out",v>> \in T) 
q1 ==  (Mutex_READ_P1 = "ko" /\ Mutex_READ_P2 = "ko") =>  (\A v \in 0..Nmax: {<<"somme",v>> }# T)  


=============================================================================
\* Modification History
\* Last modified Mon Mar 02 11:11:47 CET 2026 by mery
\* Last modified Thu Apr 02 22:16:17 CEST 2015 by mery
\* Last modified Thu Jan 29 09:08:55 CET 2015 by Terry
\* Created Tue Jan 20 09:06:57 CET 2015 by Terry
