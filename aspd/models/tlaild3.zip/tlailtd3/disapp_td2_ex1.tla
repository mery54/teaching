-------------- MODULE disapp_td2_ex1 -----------
EXTENDS TLC, Naturals
CONSTANTS v1,N
-------------------------------------------------
ASSUME v1 \in 0..N
-------------------------------------------------
VARIABLES
	x,y,w,chan,pc1,pc2
-------------------------------------------------
vars == <<x,y,w,chan,pc1,pc2>>
-------------------------------------------------
(* Processus P1 *)
act11 ==  (* action de l1 vers l2 *)
	/\ pc1="l1"
	/\ pc1' = "l2"
	/\ x'=v1
	/\ UNCHANGED <<y,pc2,chan,w>>

act12 ==  (* action de l2 vers l3 *)
	/\ pc1="l2"
	/\ pc1' = "l3"
	/\ chan'=chan \cup {<<"P1","P2",x>>}
	/\ PrintT("sending(P1,x,P3)")  
	/\ UNCHANGED <<y,pc2,x,w>>
------------------------------------------------------
init1 == x = 0 /\ pc1="l1" 
P1 == act11 \/ act12
------------------------------------------------------
(* Processus P2 *)

act21 ==  (* action de m1 vers m2 *)
	/\ pc2="m1"
	/\ pc2' = "m2"
	/\ \E u \in 0..N:  <<"P1","P2",u>> \in chan
	/\ LET val == CHOOSE  v \in chan:  v[1]="P1" /\ v[2]="P2"
	   IN  
	        /\ w' = val[3] 
	        /\ chan'=chan \ { <<"P1","P2",val[3]>>}
            /\ PrintT("receiving(P1,val,P2,chan)" ) 	        
	/\ UNCHANGED <<y,x,pc1>>
 

act22 ==  (* action de m2 vers m3 *)
	/\ pc2="m2"
	/\ pc2' = "m3"
	/\ y'= w
	/\ UNCHANGED <<pc1,x,w,chan>>

init2 == y=0 /\ w=0 /\ pc2="m1" 
P2 == act21 \/ act22
------------------------------------------------------
(* Définir le système composé *)
Init == init1 /\ init2 /\ chan={}
Next == P1 \/ P2 \/ UNCHANGED vars
------------------------------------------------------
(* Invariants *)
I1 == pc2="m3" =>  y = v1  (* violée *)
Q1 == pc2="m3" =>  y # v1  (* violée *)
(* Propriétés *)
PROP1 == [] I1
PROP2 == Init ~> y=v1
============================================