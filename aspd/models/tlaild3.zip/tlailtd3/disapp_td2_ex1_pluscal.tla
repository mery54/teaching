--------------------- MODULE disapp_td2_ex1_pluscal  ----------------------
EXTENDS Naturals, Sequences, TLC
CONSTANT val
------------------------------------------------------------
(********************************************************)
(* P sends a value val to Q                  		 *)
(******************************************************)
------------------------------------------------------------
Remove(i, seq) == [j \in 1..(Len(seq)-1) |-> 
                    IF j < i THEN seq[j] ELSE seq[j+1]]
------------------------------------------------------------
(*
--algorithm ex1l {
  variables 
    input = <<>>, 
    output = <<>>,
    msgChan = <<>>;
  macro Send(m, chan) {
    chan := Append(chan, m);
  };
  macro Recv(v, chan) {
    await chan # <<>>;  
    v := Head(chan);
    chan := Tail(chan);
  };
  
   
  process (Sender = "S")
    variables v = val;
  {
  s: Send(v, msgChan); input := Append(input,v); 
  ps: print <<"S sent  a value v=",v,"to R">>;

};
  process (Receiver = "R") 
    variables rval;
  {
  pr: print <<"R waits for   a value  from  S">>;
  r: Recv(rval, msgChan);output:=Append(output,rval);
  prr: print <<"R got  from  S",rval>>;  
  };
  
} \* end algorithm
*)    
\* BEGIN TRANSLATION (chksum(pcal) = "eebe608f" /\ chksum(tla) = "b3b0feb3")
\* Label p of process Sender at line 32 col 6 changed to p_
CONSTANT defaultInitValue
VARIABLES input, output, msgChan, pc, v, rval

vars == << input, output, msgChan, pc, v, rval >>

ProcSet == {"S"} \cup {"R"}

Init == (* Global variables *)
        /\ input = <<>>
        /\ output = <<>>
        /\ msgChan = <<>>
        (* Process Sender *)
        /\ v = val
        (* Process Receiver *)
        /\ rval = defaultInitValue
        /\ pc = [self \in ProcSet |-> CASE self = "S" -> "s"
                                        [] self = "R" -> "p"]

s == /\ pc["S"] = "s"
     /\ msgChan' = Append(msgChan, v)
     /\ input' = Append(input,v)
     /\ pc' = [pc EXCEPT !["S"] = "p_"]
     /\ UNCHANGED << output, v, rval >>

p_ == /\ pc["S"] = "p_"
      /\ PrintT(<<"S sent  a value v=",v,"to R">>)
      /\ pc' = [pc EXCEPT !["S"] = "Done"]
      /\ UNCHANGED << input, output, msgChan, v, rval >>

Sender == s \/ p_

p == /\ pc["R"] = "p"
     /\ PrintT(<<"R waits for   a value  from  S">>)
     /\ pc' = [pc EXCEPT !["R"] = "r"]
     /\ UNCHANGED << input, output, msgChan, v, rval >>

r == /\ pc["R"] = "r"
     /\ msgChan # <<>>
     /\ rval' = Head(msgChan)
     /\ msgChan' = Tail(msgChan)
     /\ output' = Append(output,rval')
     /\ pc' = [pc EXCEPT !["R"] = "q"]
     /\ UNCHANGED << input, v >>

q == /\ pc["R"] = "q"
     /\ PrintT(<<"R got  from  S",rval>>)
     /\ pc' = [pc EXCEPT !["R"] = "Done"]
     /\ UNCHANGED << input, output, msgChan, v, rval >>

Receiver == p \/ r \/ q

(* Allow infinite stuttering to prevent deadlock on termination. *)
Terminating == /\ \A self \in ProcSet: pc[self] = "Done"
               /\ UNCHANGED vars

Next == Sender \/ Receiver
           \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(\A self \in ProcSet: pc[self] = "Done")

\* END TRANSLATION 
------------------------------------------------------------
(* analysing the  specification *)
(* Invariants *)
(* What is reveived is what has been sent *)
Inv == \A i \in 1.. Len(output): input[i]=output[i]
HappyEnd == pc["R"]="Done" /\  pc["S"]="Done" => rval=val
(* Questions *)
Q1 == pc["S"] # "ps"
Q2 == msgChan = <<>>
Q3 == pc["R"] # "q"
==================================================================
