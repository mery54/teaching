----------------------------- MODULE pluscaltut10 -----------------------------
EXTENDS Integers, Sequences, TLC, FiniteSets
CONSTANTS k,l

(*

--algorithm ex3{ 
variables x = 0, y = 8;


process (one = 1)
{
  A:
    x := x + 1;
  B: 
    y := y -1;  
  C:
      assert  x \in ?? /\ y \in ???;
};

process (two = 2)
{
  D:
    x := x - 1;
  E:
    y:=y+2;
   F:
    x:= x+2;   
   assert x \in ?? /\ y \in ??;
};

}
end algorithm; 

*)

====
