----------------------------- MODULE pluscaltut2q -----------------------------
EXTENDS Integers, Sequences, TLC, FiniteSets

(*
--algorithm Tut2 { 
variables x = 0;

process (one = 1)

variables temp
{
  
 A:
	temp := x + 1;
	

	x := temp;

};  
	

process (two = 2)

variables temp
{
  B:
	temp := x + 1;
  
	x:= temp;
};
}
end algorithm; 

*)

safepc == pc[1]="Done" /\ pc[2]="Done"  => ??
====
