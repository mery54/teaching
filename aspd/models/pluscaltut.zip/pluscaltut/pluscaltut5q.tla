-------------------------------- MODULE pluscaltut5--------------------------------
EXTENDS TLC,Integers,Naturals
CONSTANTS K


(*


--algorithm ConcurrentSimple {
  variables P1,k1=0,P2,k2=K,i,F,r,t;

  process (P = 0)
  {
    start0: P1:=1;
    atome0: k1:=1;
    while1: while (k1 ?? k2) { 
        d1:P1:= k1*P1;
        d2:k1:=k1+1;
 
        };
};



  process (Q = 1)
  {
    start0: P2:=1;
    atome1: k2:=K;
    while1: while (k1 ??  k2) { 
        d1:P2:=k2*P2;
        d2:k2:=k2-1;
 
        };       
};

process (R = 2)
{ 
    start: F:=1;
    atome1: i:=0;
    while1: while (i < K) { 
            d1:F:= (i+1)*F;
            i:=i+1;
         };
    fin: print <<"F vaut",F," avec K=",K>>;    
    
};


process (S=3) 
{ 
l:await pc[0]="Done" /\ pc[1]="Done";
r:r:=P1*P2;
 p: print <<"r=",r>>;
    
};

}

*)



======
