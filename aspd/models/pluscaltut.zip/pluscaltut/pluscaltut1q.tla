----------------------------- MODULE pluscaltut1q -----------------------------
EXTENDS Integers, Sequences, TLC, FiniteSets
(*
--wf
--algorithm Tut1 { 
variables x = 0;

process (one = 1)
{
  A: assert x \in ???;
    x := x - 1;
  B: assert x \in ???? ;
    x := x * 3;
   BB: assert x \in ???; 
};

process (two = 2)
{
  C: assert x \in ???; 
    x := x + 1;
  D:
    assert x \in ??;
};

}
end algorithm; 

*)

safepc == pc[1]="Done" /\ pc[2]="Done"  => ??


====
