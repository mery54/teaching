-------------------------------- MODULE pluscaltut6 --------------------------------
EXTENDS TLC,Integers,Naturals
CONSTANTS K,L


(*
--algorithm ConcurrentSimple {
  variables n=K,P1,k1,P2,k2,F,i,r

  process (P=0)
  {
    start0: P1:=1;
    atome0: k1:=0;
    while0: while  (n ?? 1) {
        c0: n:=n-1;
        c1: P1:=L*P1;
        c2 : k1:=k1+1;
        };
        fin: print <<"fin de P">>;   
};
process (Q = 1)
  {

    start1: P2:=1;
    atome1: k2:=0;
while1: while (n ??  1) { 
        d0:n:=n-1;
        d1:P2:=L*P2;
        d2:k2:=k2+1;
 
        };  
        fin: print <<"fin de Q">>;     
};



process (R = 2)
{ 
    start: F:=1;
    atome1: i:=0;
    while1: while (i < K) { 
            d1:F:= L*F;
            i:=i+1;
         };
    fin: print <<"fin de R">>;  
    
};


process (S=3) 
{
l:await pc[0]="Done" /\ pc[1]="Done";
tt:r:=P1*P2;
 pp: print <<"r=",r>>;
    
};

}

*)
=========