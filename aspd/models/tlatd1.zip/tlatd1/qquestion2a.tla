----------------------------- MODULE qquestion2a -----------------------------
EXTENDS Integers, Sequences, TLC, FiniteSets


(*
--wf
--algorithm ex3{ 
variables x = 0, y = 8;


process (one = 1)
{
  A:
    x := x + 1;
  B: 
    y := y -1;  
  C:
      assert  ((x = 0 \/ x = 1) /\ (y = 8 \/ y = 7));
};

process (two = 2)
{
  D:
    x := x - 1;
  E:
    y:=y+2;
   F:
    x:= x+2;   
   assert ((x = 0 \/ x = -1 \/ x = 1 \/ x = 2) /\ (y = 8 \/ y = 10));
};

}
end algorithm; 

*)
====
