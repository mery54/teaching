------------------- MODULE petri14 -----------------
EXTENDS Naturals,TLC
------------------------
CONSTANTS  Places (* d\'esigne l'ensemble des places du r\'eseau de Petri  *)
------------------------          
VARIABLES  M  (*  la variable d'\'etat  indiquant o\`u se trouvent les jetons *) 
------------------------
ASSUME
   Places \subseteq {"p1", "p11","p12","p13", "p2", "p21", "p22", "p23",
   "p3", "p31", "p32", "p33", "p4", "p41", "p42", "p43"}
------------------------
l1 ==     
     M["p2"] >= 1 /\ M' =  [ [[M EXCEPT!["p2"]=M["p2"]-1] EXCEPT!["p11"]=M["p11"]+1] EXCEPT!["p13"]=M["p13"]+1]
     


------------------------
Init ==  M = [p \in Places |-> IF p \in {"p1", "p2", "p3", "p4", "p13", "p23", "p33", "p43"} THEN 1 ELSE 0]
Next == 
    \/ l1 
------------------------


=============================================================================

`