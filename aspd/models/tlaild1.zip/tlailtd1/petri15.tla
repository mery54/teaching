------------------------------- MODULE petri15 -------------------------------
(* Petri-net for the multiprocessor system *)
EXTENDS Naturals,TLC
CONSTANTS Places,P,B
VARIABLES  M
-------------------------------
(* Assumptions over  Places namely Stellen *) 
K == [p \in FPlaces |-> IF p \in {"p3"} THEN 1    ELSE 0 ]

TypeOK == M \in Places --> Nat
------------------------------------------------------------------------------------------
t1 == 
    /\ M["p1"] \geq 1 /\ M["p3"]+1 \leq K["p3"]
    /\ M'= [[M EXCEPT!["p3"]=M["p3"]+1] EXCEPT!["p1"]=M["p1"]-1] 

t2 == 
    /\ M["p2"] \geq 1 /\ M["p3"] \geq 1
    /\ M'=[[[M  EXCEPT!["p3"]=M["p3"]-1] 
                EXCEPT!["p2"]=M["p2"]-1]    
                EXCEPT!["p4"]=M["p4"]+1]


t3 == 
    /\ M["p2"] \geq 1 /\ M["p3"] \geq 1 /\ M["p4"] \geq 1
    /\ M'=[[M   EXCEPT!["p3"]=M["p3"]-1] 
                EXCEPT!["p5"]=M["p5"]+1]

t4 == 
    /\ M["p4"] \geq 1
    /\ M'=[[[M  EXCEPT!["p4"]=M["p4"]-1] 
                EXCEPT!["p2"]=M["p2"]+1] 
                EXCEPT!["p1"]=M["p1"]+1]


t5 == 
    /\ M["p4"] \geq 1 /\ M["p5"] \geq 1
    /\ M'=[[M   EXCEPT!["p5"]=M["p5"]-1] 
                EXCEPT!["p1"]=M["p1"]+1]

------------------------------------------------------------------------------------------


Init ==  M = [p \in Places |-> 
            IF p \in {"p1"} THEN P      
            ELSE IF p \in {"p2"} 
            THEN B  ELSE 0 ]



Next == t1 \/ t2 \/ t3 \/ t4 \/ t5

Petri  == Init /\ [][Next]_<<M>>

 
I0 ==  \A p \in Places :  M[p] \geq 0


I1 == 0 \leq M["p3"] /\ M["p3"] \leq 1
I2 ==  M["p1"] \leq 5 /\ M["p2"] \leq 2
I3 ==  \A p \in {"p5"} : 0 \leq M[p] /\ M[p] \leq 5
I4 ==  \A p \in {"p4"} : 0 \leq M[p] /\ M[p] \leq 2


AP4 == M["p4"] = 0
AP5 == M["p5"] = 0
Test == I0 /\ I1 /\ I2 /\ I3 /\ I4 
=============================================================================



