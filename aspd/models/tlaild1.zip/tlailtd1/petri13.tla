-------------------------------- MODULE petri13 -----------
EXTENDS Naturals,TLC
------------------------------
VARIABLES M
---------------------------------
CONSTANT Places,N
--------------------------------------
TypeOK == M \in [Places -> Nat]
----------------------------------------
\* condition de t1
t1 == 
        /\ M["p1"] \geq 1 
        /\  M' = [[M  EXCEPT! ["p1"] = @-1] EXCEPT!["p2"] = @+1]

t2 == 
        /\ M["p1"] \geq 1 
        /\  M' = [[M  EXCEPT! ["p1"] = @-1] EXCEPT!["p3"] = @+1] 

t3 == 
        /\ M["p2"] \geq 1 
        /\  M' = [[M  EXCEPT! ["p2"] = @-1] EXCEPT!["p5"] = @+1] 

t4 == 
        /\ M["p3"] \geq 1 /\ M["p4"] < N
        /\  M' = [[[[ M EXCEPT! ["p1"] = @+1] EXCEPT! ["p7"] = @+1] EXCEPT!["p4"] = @+1] EXCEPT!["p3"] = @-1]

t5 ==
       /\ M["p5"] \geq 1 /\ M["p4"] < N
        /\  M' = [[[[M  EXCEPT! ["p1"] = @+1] EXCEPT!["p6"] = @+1]  EXCEPT!["p4"] = @+1] EXCEPT!["p5"] = @-1]
	
-----------------------
(* defining the systrem *)
Init ==  M = [p \in Places |-> IF p \in {"p1"} THEN 1 ELSE 0]
Next == t1 \/ t2 \/ t3 \/ t4 \/ t5
----------------------------------------------
(* analysiong properties of nthe system *)
P1 == M["p4"] = M["p6"]+M["p7"]
P2 == M["p1"] + M["p2"]+M["p3"]+M["p5"] =1
=============================================================================