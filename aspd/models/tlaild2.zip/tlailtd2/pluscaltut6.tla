-------------------------------- MODULE pluscaltut6 --------------------------------
EXTENDS TLC,Integers,Naturals
CONSTANTS K,L


(*
--algorithm ConcurrentSimple {
  variables n=K,P1,k1,P2,k2,F,i,r

  process (P=0)
  {
    start0: P1:=1;
    atome0: k1:=0;
    while0: while  (n > 1) {
        c0: n:=n-1;
        c1: P1:=L*P1;
        c2 : k1:=k1+1;
        };
        fin: print <<"fin de P">>;   
};
process (Q = 1)
  {

    start1: P2:=1;
    atome1: k2:=0;
while1: while (n >  1) { 
        d0:n:=n-1;
        d1:P2:=L*P2;
        d2:k2:=k2+1;
 
        };  
        fin: print <<"fin de Q">>;     
};



process (R = 2)
{ 
    start: F:=1;
    atome1: i:=0;
    while1: while (i < K) { 
            d1:F:= L*F;
            i:=i+1;
         };
    fin: print <<"fin de R">>;  
    
};


process (S=3) 
{
l:await pc[0]="Done" /\ pc[1]="Done";
uu: if (k1+k2=K) 
    {tt:r:=P1*P2;}
    else
    {qq:r:=P1*P2*L;};
 pp: print <<"r=",r>>;
    
};

}

*)
\* BEGIN TRANSLATION (chksum(pcal) = "97c3d041" /\ chksum(tla) = "7b84afb5")
\* Label fin of process P at line 19 col 14 changed to fin_
\* Label atome1 of process Q at line 25 col 13 changed to atome1_
\* Label while1 of process Q at line 26 col 9 changed to while1_
\* Label d1 of process Q at line 28 col 12 changed to d1_
\* Label fin of process Q at line 32 col 14 changed to fin_Q
CONSTANT defaultInitValue
VARIABLES n, P1, k1, P2, k2, F, i, r, pc

vars == << n, P1, k1, P2, k2, F, i, r, pc >>

ProcSet == {0} \cup {1} \cup {2} \cup {3}

Init == (* Global variables *)
        /\ n = K
        /\ P1 = defaultInitValue
        /\ k1 = defaultInitValue
        /\ P2 = defaultInitValue
        /\ k2 = defaultInitValue
        /\ F = defaultInitValue
        /\ i = defaultInitValue
        /\ r = defaultInitValue
        /\ pc = [self \in ProcSet |-> CASE self = 0 -> "start0"
                                        [] self = 1 -> "start1"
                                        [] self = 2 -> "start"
                                        [] self = 3 -> "l"]

start0 == /\ pc[0] = "start0"
          /\ P1' = 1
          /\ pc' = [pc EXCEPT ![0] = "atome0"]
          /\ UNCHANGED << n, k1, P2, k2, F, i, r >>

atome0 == /\ pc[0] = "atome0"
          /\ k1' = 0
          /\ pc' = [pc EXCEPT ![0] = "while0"]
          /\ UNCHANGED << n, P1, P2, k2, F, i, r >>

while0 == /\ pc[0] = "while0"
          /\ IF n > 1
                THEN /\ pc' = [pc EXCEPT ![0] = "c0"]
                ELSE /\ pc' = [pc EXCEPT ![0] = "fin_"]
          /\ UNCHANGED << n, P1, k1, P2, k2, F, i, r >>

c0 == /\ pc[0] = "c0"
      /\ n' = n-1
      /\ pc' = [pc EXCEPT ![0] = "c1"]
      /\ UNCHANGED << P1, k1, P2, k2, F, i, r >>

c1 == /\ pc[0] = "c1"
      /\ P1' = L*P1
      /\ pc' = [pc EXCEPT ![0] = "c2"]
      /\ UNCHANGED << n, k1, P2, k2, F, i, r >>

c2 == /\ pc[0] = "c2"
      /\ k1' = k1+1
      /\ pc' = [pc EXCEPT ![0] = "while0"]
      /\ UNCHANGED << n, P1, P2, k2, F, i, r >>

fin_ == /\ pc[0] = "fin_"
        /\ PrintT(<<"fin de P">>)
        /\ pc' = [pc EXCEPT ![0] = "Done"]
        /\ UNCHANGED << n, P1, k1, P2, k2, F, i, r >>

P == start0 \/ atome0 \/ while0 \/ c0 \/ c1 \/ c2 \/ fin_

start1 == /\ pc[1] = "start1"
          /\ P2' = 1
          /\ pc' = [pc EXCEPT ![1] = "atome1_"]
          /\ UNCHANGED << n, P1, k1, k2, F, i, r >>

atome1_ == /\ pc[1] = "atome1_"
           /\ k2' = 0
           /\ pc' = [pc EXCEPT ![1] = "while1_"]
           /\ UNCHANGED << n, P1, k1, P2, F, i, r >>

while1_ == /\ pc[1] = "while1_"
           /\ IF n >  1
                 THEN /\ pc' = [pc EXCEPT ![1] = "d0"]
                 ELSE /\ pc' = [pc EXCEPT ![1] = "fin_Q"]
           /\ UNCHANGED << n, P1, k1, P2, k2, F, i, r >>

d0 == /\ pc[1] = "d0"
      /\ n' = n-1
      /\ pc' = [pc EXCEPT ![1] = "d1_"]
      /\ UNCHANGED << P1, k1, P2, k2, F, i, r >>

d1_ == /\ pc[1] = "d1_"
       /\ P2' = L*P2
       /\ pc' = [pc EXCEPT ![1] = "d2"]
       /\ UNCHANGED << n, P1, k1, k2, F, i, r >>

d2 == /\ pc[1] = "d2"
      /\ k2' = k2+1
      /\ pc' = [pc EXCEPT ![1] = "while1_"]
      /\ UNCHANGED << n, P1, k1, P2, F, i, r >>

fin_Q == /\ pc[1] = "fin_Q"
         /\ PrintT(<<"fin de Q">>)
         /\ pc' = [pc EXCEPT ![1] = "Done"]
         /\ UNCHANGED << n, P1, k1, P2, k2, F, i, r >>

Q == start1 \/ atome1_ \/ while1_ \/ d0 \/ d1_ \/ d2 \/ fin_Q

start == /\ pc[2] = "start"
         /\ F' = 1
         /\ pc' = [pc EXCEPT ![2] = "atome1"]
         /\ UNCHANGED << n, P1, k1, P2, k2, i, r >>

atome1 == /\ pc[2] = "atome1"
          /\ i' = 0
          /\ pc' = [pc EXCEPT ![2] = "while1"]
          /\ UNCHANGED << n, P1, k1, P2, k2, F, r >>

while1 == /\ pc[2] = "while1"
          /\ IF i < K
                THEN /\ pc' = [pc EXCEPT ![2] = "d1"]
                ELSE /\ pc' = [pc EXCEPT ![2] = "fin"]
          /\ UNCHANGED << n, P1, k1, P2, k2, F, i, r >>

d1 == /\ pc[2] = "d1"
      /\ F' = L*F
      /\ i' = i+1
      /\ pc' = [pc EXCEPT ![2] = "while1"]
      /\ UNCHANGED << n, P1, k1, P2, k2, r >>

fin == /\ pc[2] = "fin"
       /\ PrintT(<<"fin de R">>)
       /\ pc' = [pc EXCEPT ![2] = "Done"]
       /\ UNCHANGED << n, P1, k1, P2, k2, F, i, r >>

R == start \/ atome1 \/ while1 \/ d1 \/ fin

l == /\ pc[3] = "l"
     /\ pc[0]="Done" /\ pc[1]="Done"
     /\ pc' = [pc EXCEPT ![3] = "uu"]
     /\ UNCHANGED << n, P1, k1, P2, k2, F, i, r >>

uu == /\ pc[3] = "uu"
      /\ IF k1+k2=K
            THEN /\ pc' = [pc EXCEPT ![3] = "tt"]
            ELSE /\ pc' = [pc EXCEPT ![3] = "qq"]
      /\ UNCHANGED << n, P1, k1, P2, k2, F, i, r >>

tt == /\ pc[3] = "tt"
      /\ r' = P1*P2
      /\ pc' = [pc EXCEPT ![3] = "pp"]
      /\ UNCHANGED << n, P1, k1, P2, k2, F, i >>

qq == /\ pc[3] = "qq"
      /\ r' = P1*P2*L
      /\ pc' = [pc EXCEPT ![3] = "pp"]
      /\ UNCHANGED << n, P1, k1, P2, k2, F, i >>

pp == /\ pc[3] = "pp"
      /\ PrintT(<<"r=",r>>)
      /\ pc' = [pc EXCEPT ![3] = "Done"]
      /\ UNCHANGED << n, P1, k1, P2, k2, F, i, r >>

S == l \/ uu \/ tt \/ qq \/ pp

(* Allow infinite stuttering to prevent deadlock on termination. *)
Terminating == /\ \A self \in ProcSet: pc[self] = "Done"
               /\ UNCHANGED vars

Next == P \/ Q \/ R \/ S
           \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(\A self \in ProcSet: pc[self] = "Done")

\* END TRANSLATION



the == pc[0]="Done" /\ pc[1]="Done" /\ pc[2]="Done" /\ pc[3]="Done" =>  r=F
thequestion == pc[0]="Done" /\ pc[1]="Done" => pc[3] # "qq" /\ k2=0

======

\* L^K
