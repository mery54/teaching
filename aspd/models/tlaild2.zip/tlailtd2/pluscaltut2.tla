----------------------------- MODULE pluscaltut2 -----------------------------
EXTENDS Integers, Sequences, TLC, FiniteSets

(*
--algorithm Tut2 { 
variables x = 0;

process (one = 1)

variables temp
{
  
 A:
	temp := x + 1;
AA:

	x := temp;

};  
	

process (two = 2)

variables temp
{
  B:
	temp := x + 1;
   BB:
   	x:= temp;
};
}
end algorithm; 

*)
\* BEGIN TRANSLATION (chksum(pcal) = "8775a1c3" /\ chksum(tla) = "88315877")
\* Process variable temp of process one at line 10 col 11 changed to temp_
CONSTANT defaultInitValue
VARIABLES x, pc, temp_, temp

vars == << x, pc, temp_, temp >>

ProcSet == {1} \cup {2}

Init == (* Global variables *)
        /\ x = 0
        (* Process one *)
        /\ temp_ = defaultInitValue
        (* Process two *)
        /\ temp = defaultInitValue
        /\ pc = [self \in ProcSet |-> CASE self = 1 -> "A"
                                        [] self = 2 -> "B"]

A == /\ pc[1] = "A"
     /\ temp_' = x + 1
     /\ pc' = [pc EXCEPT ![1] = "AA"]
     /\ UNCHANGED << x, temp >>

AA == /\ pc[1] = "AA"
      /\ x' = temp_
      /\ pc' = [pc EXCEPT ![1] = "Done"]
      /\ UNCHANGED << temp_, temp >>

one == A \/ AA

B == /\ pc[2] = "B"
     /\ temp' = x + 1
     /\ pc' = [pc EXCEPT ![2] = "BB"]
     /\ UNCHANGED << x, temp_ >>

BB == /\ pc[2] = "BB"
      /\ x' = temp
      /\ pc' = [pc EXCEPT ![2] = "Done"]
      /\ UNCHANGED << temp_, temp >>

two == B \/ BB

(* Allow infinite stuttering to prevent deadlock on termination. *)
Terminating == /\ \A self \in ProcSet: pc[self] = "Done"
               /\ UNCHANGED vars

Next == one \/ two
           \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(\A self \in ProcSet: pc[self] = "Done")

\* END TRANSLATION 

I1 == pc[1] ="Done" /\ pc[2]="Done" => x \in {1,2}


====
