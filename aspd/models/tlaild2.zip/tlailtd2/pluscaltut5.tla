-------------------------------- MODULE pluscaltut5--------------------------------
EXTENDS TLC,Integers,Naturals
CONSTANTS K


(*


--algorithm ConcurrentSimple {
  variables P1,k1=0,P2,k2=K,i,F,r,t;

  process (P = 0)
  {
    start0: P1:=1;
    atome0: k1:=1;
    while1: while (k1 < k2) { 
        d1:P1:= k1*P1;
        d2:k1:=k1+1;
 
        };
};



  process (Q = 1)
  {
    start0: P2:=1;
    atome1: k2:=K;
    while1: while (k1 <  k2) { 
        d1:P2:=k2*P2;
        d2:k2:=k2-1;
 
        };       
};

process (R = 2)
{ 
    start: F:=1;
    atome1: i:=0;
    while1: while (i < K) { 
            d1:F:= (i+1)*F;
            i:=i+1;
         };
    fin: print <<"F vaut",F," avec K=",K>>;    
    
};


process (S=3) 
{ 
l:await pc[0]="Done" /\ pc[1]="Done";
uu: if (k1>k2) 
    {rr:r:=P1*P2;}
    else
    {qq: r:=P1*P2*k2;};
 pp: print <<"t=",t>>;
    
};


process (T=4) 
{
l:await pc[0]="Done" /\ pc[1]="Done";
uu: t:=P1*P2;    
pp: print <<"t=",t>>;
    
};
}

*)
\* BEGIN TRANSLATION (chksum(pcal) = "4eeb7d69" /\ chksum(tla) = "fdde0243")
\* Label start0 of process P at line 14 col 13 changed to start0_
\* Label while1 of process P at line 16 col 13 changed to while1_
\* Label d1 of process P at line 17 col 12 changed to d1_
\* Label d2 of process P at line 18 col 12 changed to d2_
\* Label atome1 of process Q at line 28 col 13 changed to atome1_
\* Label while1 of process Q at line 29 col 13 changed to while1_Q
\* Label d1 of process Q at line 30 col 12 changed to d1_Q
\* Label l of process S at line 51 col 3 changed to l_
\* Label uu of process S at line 52 col 5 changed to uu_
\* Label pp of process S at line 56 col 6 changed to pp_
CONSTANT defaultInitValue
VARIABLES P1, k1, P2, k2, i, F, r, t, pc

vars == << P1, k1, P2, k2, i, F, r, t, pc >>

ProcSet == {0} \cup {1} \cup {2} \cup {3} \cup {4}

Init == (* Global variables *)
        /\ P1 = defaultInitValue
        /\ k1 = 0
        /\ P2 = defaultInitValue
        /\ k2 = K
        /\ i = defaultInitValue
        /\ F = defaultInitValue
        /\ r = defaultInitValue
        /\ t = defaultInitValue
        /\ pc = [self \in ProcSet |-> CASE self = 0 -> "start0_"
                                        [] self = 1 -> "start0"
                                        [] self = 2 -> "start"
                                        [] self = 3 -> "l_"
                                        [] self = 4 -> "l"]

start0_ == /\ pc[0] = "start0_"
           /\ P1' = 1
           /\ pc' = [pc EXCEPT ![0] = "atome0"]
           /\ UNCHANGED << k1, P2, k2, i, F, r, t >>

atome0 == /\ pc[0] = "atome0"
          /\ k1' = 1
          /\ pc' = [pc EXCEPT ![0] = "while1_"]
          /\ UNCHANGED << P1, P2, k2, i, F, r, t >>

while1_ == /\ pc[0] = "while1_"
           /\ IF k1 < k2
                 THEN /\ pc' = [pc EXCEPT ![0] = "d1_"]
                 ELSE /\ pc' = [pc EXCEPT ![0] = "Done"]
           /\ UNCHANGED << P1, k1, P2, k2, i, F, r, t >>

d1_ == /\ pc[0] = "d1_"
       /\ P1' = k1*P1
       /\ pc' = [pc EXCEPT ![0] = "d2_"]
       /\ UNCHANGED << k1, P2, k2, i, F, r, t >>

d2_ == /\ pc[0] = "d2_"
       /\ k1' = k1+1
       /\ pc' = [pc EXCEPT ![0] = "while1_"]
       /\ UNCHANGED << P1, P2, k2, i, F, r, t >>

P == start0_ \/ atome0 \/ while1_ \/ d1_ \/ d2_

start0 == /\ pc[1] = "start0"
          /\ P2' = 1
          /\ pc' = [pc EXCEPT ![1] = "atome1_"]
          /\ UNCHANGED << P1, k1, k2, i, F, r, t >>

atome1_ == /\ pc[1] = "atome1_"
           /\ k2' = K
           /\ pc' = [pc EXCEPT ![1] = "while1_Q"]
           /\ UNCHANGED << P1, k1, P2, i, F, r, t >>

while1_Q == /\ pc[1] = "while1_Q"
            /\ IF k1 <  k2
                  THEN /\ pc' = [pc EXCEPT ![1] = "d1_Q"]
                  ELSE /\ pc' = [pc EXCEPT ![1] = "Done"]
            /\ UNCHANGED << P1, k1, P2, k2, i, F, r, t >>

d1_Q == /\ pc[1] = "d1_Q"
        /\ P2' = k2*P2
        /\ pc' = [pc EXCEPT ![1] = "d2"]
        /\ UNCHANGED << P1, k1, k2, i, F, r, t >>

d2 == /\ pc[1] = "d2"
      /\ k2' = k2-1
      /\ pc' = [pc EXCEPT ![1] = "while1_Q"]
      /\ UNCHANGED << P1, k1, P2, i, F, r, t >>

Q == start0 \/ atome1_ \/ while1_Q \/ d1_Q \/ d2

start == /\ pc[2] = "start"
         /\ F' = 1
         /\ pc' = [pc EXCEPT ![2] = "atome1"]
         /\ UNCHANGED << P1, k1, P2, k2, i, r, t >>

atome1 == /\ pc[2] = "atome1"
          /\ i' = 0
          /\ pc' = [pc EXCEPT ![2] = "while1"]
          /\ UNCHANGED << P1, k1, P2, k2, F, r, t >>

while1 == /\ pc[2] = "while1"
          /\ IF i < K
                THEN /\ pc' = [pc EXCEPT ![2] = "d1"]
                ELSE /\ pc' = [pc EXCEPT ![2] = "fin"]
          /\ UNCHANGED << P1, k1, P2, k2, i, F, r, t >>

d1 == /\ pc[2] = "d1"
      /\ F' = (i+1)*F
      /\ i' = i+1
      /\ pc' = [pc EXCEPT ![2] = "while1"]
      /\ UNCHANGED << P1, k1, P2, k2, r, t >>

fin == /\ pc[2] = "fin"
       /\ PrintT(<<"F vaut",F," avec K=",K>>)
       /\ pc' = [pc EXCEPT ![2] = "Done"]
       /\ UNCHANGED << P1, k1, P2, k2, i, F, r, t >>

R == start \/ atome1 \/ while1 \/ d1 \/ fin

l_ == /\ pc[3] = "l_"
      /\ pc[0]="Done" /\ pc[1]="Done"
      /\ pc' = [pc EXCEPT ![3] = "uu_"]
      /\ UNCHANGED << P1, k1, P2, k2, i, F, r, t >>

uu_ == /\ pc[3] = "uu_"
       /\ IF k1>k2
             THEN /\ pc' = [pc EXCEPT ![3] = "rr"]
             ELSE /\ pc' = [pc EXCEPT ![3] = "qq"]
       /\ UNCHANGED << P1, k1, P2, k2, i, F, r, t >>

rr == /\ pc[3] = "rr"
      /\ r' = P1*P2
      /\ pc' = [pc EXCEPT ![3] = "pp_"]
      /\ UNCHANGED << P1, k1, P2, k2, i, F, t >>

qq == /\ pc[3] = "qq"
      /\ r' = P1*P2*k2
      /\ pc' = [pc EXCEPT ![3] = "pp_"]
      /\ UNCHANGED << P1, k1, P2, k2, i, F, t >>

pp_ == /\ pc[3] = "pp_"
       /\ PrintT(<<"t=",t>>)
       /\ pc' = [pc EXCEPT ![3] = "Done"]
       /\ UNCHANGED << P1, k1, P2, k2, i, F, r, t >>

S == l_ \/ uu_ \/ rr \/ qq \/ pp_

l == /\ pc[4] = "l"
     /\ pc[0]="Done" /\ pc[1]="Done"
     /\ pc' = [pc EXCEPT ![4] = "uu"]
     /\ UNCHANGED << P1, k1, P2, k2, i, F, r, t >>

uu == /\ pc[4] = "uu"
      /\ t' = P1*P2
      /\ pc' = [pc EXCEPT ![4] = "pp"]
      /\ UNCHANGED << P1, k1, P2, k2, i, F, r >>

pp == /\ pc[4] = "pp"
      /\ PrintT(<<"t=",t>>)
      /\ pc' = [pc EXCEPT ![4] = "Done"]
      /\ UNCHANGED << P1, k1, P2, k2, i, F, r, t >>

T == l \/ uu \/ pp

(* Allow infinite stuttering to prevent deadlock on termination. *)
Terminating == /\ \A self \in ProcSet: pc[self] = "Done"
               /\ UNCHANGED vars

Next == P \/ Q \/ R \/ S \/ T
           \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(\A self \in ProcSet: pc[self] = "Done")

\* END TRANSLATION 


QQ ==  pc[0]="Done" /\ pc[1]="Done"  /\ pc[2]="Done"/\ pc[3]="Done"=> t=F

PC == pc[0]="Done" /\ pc[1]="Done"  /\ pc[2]="Done"/\ pc[3]="Done"=> r=F
Test1 == pc[0]="Done" /\ pc[1]="Done"  =>  k1\geq k2
Toto == pc[3] # "qq"
test == Toto
======
