/* mcfsi0_factorial1_spec.c: executable versions of the specification
   functions of the Event-B context, synthesized by eb2pcal from the axioms
   (the axiom of each case is given in a comment). They are used by the
   functions called by the algorithm and by the run-time check of the
   postcondition in main.c. */

#include <stdio.h>
#include <stdlib.h>
#include "mcfsi0_factorial1.h"

/* factorial: function of the specification (logic) */
int factorial(int x)
{
  if (x == 0) return 1;   /* A-functions_th2 (theorem) */
  if (((0 <= x) && x != 0)) return x * factorial(x - 1);   /* A-functions_th3 (theorem) */
  fprintf(stderr, "factorial: undefined for these arguments\n");
  exit(2);
}
