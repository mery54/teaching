/* main.c: runs the algorithm mcfsi0_factorial1 on examples and checks, at run
   time, its precondition and its postcondition (defined by the event(s) of
   the first machine of the Event-B development). */

#include <stdio.h>
#include <stdlib.h>
#include "mcfsi0_factorial1.h"

static int failures = 0;

static void check(int ok, const char *what)
{
  if (!ok) {
    printf("  postcondition FAILED: %s\n", what);
    failures++;
  }
}

/* one run of the algorithm */
static void run(int n0)
{
  printf("mcfsi0_factorial1(n0=%d)\n", n0);
  if (!(0 <= n0)) {   /* precondition A-functions_req1 */
    printf("  precondition A-functions_req1 not satisfied: example skipped\n");
    return;
  }
  int result = mcfsi0_factorial1(n0);
  printf("  result r = %d\n", result);
  /* postcondition (computing1 of B-prepostok): r = factorial(n) */
  int before = failures;
  check(result == factorial(n0), "r = factorial(n)");
  if (failures == before) printf("  postcondition OK\n");
}

int main(int argc, char **argv)
{
  if (argc == 2) {   /* ./run n0 */
    run(atoi(argv[1]));
  } else {
    run(0);
    run(1);
    run(2);
    run(3);
    run(5);
    run(8);
  }
  printf("%s\n", failures ? "FAILURES" : "all the examples satisfy the postcondition");
  return failures != 0;
}
