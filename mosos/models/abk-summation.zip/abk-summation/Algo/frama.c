/*@ requires n > 0 && \valid(v+(1..n)); 
  @ assigns \nothing;
@ ensures -1 \result == u(; 

@*/
int sum(double v[]à;
	
