(* File containing proof attempts.
Rename this file before editing because any changes will be overwritten when exporting next time. *)
theory "algorithm_0_interactive" imports "algorithm_0" begin

(* INITIALISATION_inv1_INV *)
sublocale "INITIALISATION_inv1_INV_hyps" < "INITIALISATION_inv1_INV_goal"
apply (insert INITIALISATION_inv1_INV_hyps_axioms)
unfolding "INITIALISATION_inv1_INV_goal_def" "INITIALISATION_inv1_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* INITIALISATION_inv3_INV *)
sublocale "INITIALISATION_inv3_INV_hyps" < "INITIALISATION_inv3_INV_goal"
apply (insert INITIALISATION_inv3_INV_hyps_axioms)
unfolding "INITIALISATION_inv3_INV_goal_def" "INITIALISATION_inv3_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* INITIALISATION_inv4_INV *)
sublocale "INITIALISATION_inv4_INV_hyps" < "INITIALISATION_inv4_INV_goal"
apply (insert INITIALISATION_inv4_INV_hyps_axioms)
unfolding "INITIALISATION_inv4_INV_goal_def" "INITIALISATION_inv4_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* INITIALISATION_inv5_INV *)
sublocale "INITIALISATION_inv5_INV_hyps" < "INITIALISATION_inv5_INV_goal"
apply (insert INITIALISATION_inv5_INV_hyps_axioms)
unfolding "INITIALISATION_inv5_INV_goal_def" "INITIALISATION_inv5_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* INITIALISATION_inv6_INV *)
sublocale "INITIALISATION_inv6_INV_hyps" < "INITIALISATION_inv6_INV_goal"
apply (insert INITIALISATION_inv6_INV_hyps_axioms)
unfolding "INITIALISATION_inv6_INV_goal_def" "INITIALISATION_inv6_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* INITIALISATION_pre_INV *)
sublocale "INITIALISATION_pre_INV_hyps" < "INITIALISATION_pre_INV_goal"
apply (insert INITIALISATION_pre_INV_hyps_axioms)
unfolding "INITIALISATION_pre_INV_goal_def" "INITIALISATION_pre_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* INITIALISATION_post_INV *)
sublocale "INITIALISATION_post_INV_hyps" < "INITIALISATION_post_INV_goal"
apply (insert INITIALISATION_post_INV_hyps_axioms)
unfolding "INITIALISATION_post_INV_goal_def" "INITIALISATION_post_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el0l1_inv3_INV *)
sublocale "el0l1_inv3_INV_hyps" < "el0l1_inv3_INV_goal"
apply (insert el0l1_inv3_INV_hyps_axioms)
unfolding "el0l1_inv3_INV_goal_def" "el0l1_inv3_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el0l1_inv4_INV *)
sublocale "el0l1_inv4_INV_hyps" < "el0l1_inv4_INV_goal"
apply (insert el0l1_inv4_INV_hyps_axioms)
unfolding "el0l1_inv4_INV_goal_def" "el0l1_inv4_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el0l1_inv5_INV *)
sublocale "el0l1_inv5_INV_hyps" < "el0l1_inv5_INV_goal"
apply (insert el0l1_inv5_INV_hyps_axioms)
unfolding "el0l1_inv5_INV_goal_def" "el0l1_inv5_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el0l1_inv6_INV *)
sublocale "el0l1_inv6_INV_hyps" < "el0l1_inv6_INV_goal"
apply (insert el0l1_inv6_INV_hyps_axioms)
unfolding "el0l1_inv6_INV_goal_def" "el0l1_inv6_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el0l3_inv3_INV *)
sublocale "el0l3_inv3_INV_hyps" < "el0l3_inv3_INV_goal"
apply (insert el0l3_inv3_INV_hyps_axioms)
unfolding "el0l3_inv3_INV_goal_def" "el0l3_inv3_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el0l3_inv4_INV *)
sublocale "el0l3_inv4_INV_hyps" < "el0l3_inv4_INV_goal"
apply (insert el0l3_inv4_INV_hyps_axioms)
unfolding "el0l3_inv4_INV_goal_def" "el0l3_inv4_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el0l3_inv5_INV *)
sublocale "el0l3_inv5_INV_hyps" < "el0l3_inv5_INV_goal"
apply (insert el0l3_inv5_INV_hyps_axioms)
unfolding "el0l3_inv5_INV_goal_def" "el0l3_inv5_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el0l3_inv6_INV *)
sublocale "el0l3_inv6_INV_hyps" < "el0l3_inv6_INV_goal"
apply (insert el0l3_inv6_INV_hyps_axioms)
unfolding "el0l3_inv6_INV_goal_def" "el0l3_inv6_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el1l2_inv1_INV *)
sublocale "el1l2_inv1_INV_hyps" < "el1l2_inv1_INV_goal"
apply (insert el1l2_inv1_INV_hyps_axioms)
unfolding "el1l2_inv1_INV_goal_def" "el1l2_inv1_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el1l2_inv3_INV *)
sublocale "el1l2_inv3_INV_hyps" < "el1l2_inv3_INV_goal"
apply (insert el1l2_inv3_INV_hyps_axioms)
unfolding "el1l2_inv3_INV_goal_def" "el1l2_inv3_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el1l2_inv4_INV *)
sublocale "el1l2_inv4_INV_hyps" < "el1l2_inv4_INV_goal"
apply (insert el1l2_inv4_INV_hyps_axioms)
unfolding "el1l2_inv4_INV_goal_def" "el1l2_inv4_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el1l2_inv5_INV *)
sublocale "el1l2_inv5_INV_hyps" < "el1l2_inv5_INV_goal"
apply (insert el1l2_inv5_INV_hyps_axioms)
unfolding "el1l2_inv5_INV_goal_def" "el1l2_inv5_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el1l2_inv6_INV *)
sublocale "el1l2_inv6_INV_hyps" < "el1l2_inv6_INV_goal"
apply (insert el1l2_inv6_INV_hyps_axioms)
unfolding "el1l2_inv6_INV_goal_def" "el1l2_inv6_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

end
