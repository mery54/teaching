(* File containing proof attempts.
Rename this file before editing because any changes will be overwritten when exporting next time. *)
theory "algorithm_1_interactive" imports "algorithm_1" begin

(* el1l2_pre_INV *)
sublocale "el1l2_pre_INV_hyps" < "el1l2_pre_INV_goal"
apply (insert el1l2_pre_INV_hyps_axioms)
unfolding "el1l2_pre_INV_goal_def" "el1l2_pre_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el1l2_post_INV *)
sublocale "el1l2_post_INV_hyps" < "el1l2_post_INV_goal"
apply (insert el1l2_post_INV_hyps_axioms)
unfolding "el1l2_post_INV_goal_def" "el1l2_post_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el2l1_inv3_INV *)
sublocale "el2l1_inv3_INV_hyps" < "el2l1_inv3_INV_goal"
apply (insert el2l1_inv3_INV_hyps_axioms)
unfolding "el2l1_inv3_INV_goal_def" "el2l1_inv3_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el2l1_inv4_INV *)
sublocale "el2l1_inv4_INV_hyps" < "el2l1_inv4_INV_goal"
apply (insert el2l1_inv4_INV_hyps_axioms)
unfolding "el2l1_inv4_INV_goal_def" "el2l1_inv4_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el2l1_inv5_INV *)
sublocale "el2l1_inv5_INV_hyps" < "el2l1_inv5_INV_goal"
apply (insert el2l1_inv5_INV_hyps_axioms)
unfolding "el2l1_inv5_INV_goal_def" "el2l1_inv5_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el2l1_inv6_INV *)
sublocale "el2l1_inv6_INV_hyps" < "el2l1_inv6_INV_goal"
apply (insert el2l1_inv6_INV_hyps_axioms)
unfolding "el2l1_inv6_INV_goal_def" "el2l1_inv6_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el2l3_inv3_INV *)
sublocale "el2l3_inv3_INV_hyps" < "el2l3_inv3_INV_goal"
apply (insert el2l3_inv3_INV_hyps_axioms)
unfolding "el2l3_inv3_INV_goal_def" "el2l3_inv3_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el2l3_inv4_INV *)
sublocale "el2l3_inv4_INV_hyps" < "el2l3_inv4_INV_goal"
apply (insert el2l3_inv4_INV_hyps_axioms)
unfolding "el2l3_inv4_INV_goal_def" "el2l3_inv4_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el2l3_inv5_INV *)
sublocale "el2l3_inv5_INV_hyps" < "el2l3_inv5_INV_goal"
apply (insert el2l3_inv5_INV_hyps_axioms)
unfolding "el2l3_inv5_INV_goal_def" "el2l3_inv5_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

(* el2l3_inv6_INV *)
sublocale "el2l3_inv6_INV_hyps" < "el2l3_inv6_INV_goal"
apply (insert el2l3_inv6_INV_hyps_axioms)
unfolding "el2l3_inv6_INV_goal_def" "el2l3_inv6_INV_hyps_def" "AUX"
apply (elim HOL.conjE)?

apply (ebsimp', axe'?)
assert_finished
oops

end
